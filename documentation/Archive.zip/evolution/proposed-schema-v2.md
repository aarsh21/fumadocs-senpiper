# Proposed Schema V2

A redesigned schema addressing the [current limitations](./current-limitations.md).

---

## Design Principles

1. **Separation of Concerns** - Split data, UI, logic, and styling
2. **Type Safety** - Strongly-typed field definitions
3. **Composition** - Reusable components
4. **Flexibility** - Support forms, pages, dashboards
5. **Explicit State** - First-class state management
6. **API-First** - Native integration support
7. **Progressive** - Gradual migration from V1

---

## High-Level Structure

```yaml
# Schema V2 Structure
schema:
  version: "2.0.0"
  type: "form" | "page" | "wizard" | "dashboard"
  
  # Metadata
  meta:
    id: "uuid"
    name: "Customer Registration"
    description: "..."
    
  # Data model (what data exists)
  model:
    fields: { ... }
    variables: { ... }
    
  # UI definition (how it looks)
  ui:
    pages: [ ... ]
    layout: { ... }
    theme: { ... }
    
  # Logic (how it behaves)  
  logic:
    computed: { ... }
    validations: { ... }
    effects: { ... }
    
  # External integrations
  integrations:
    apis: { ... }
    masters: { ... }
    
  # Access control
  access:
    roles: { ... }
    rules: { ... }
```

---

## 1. Model Layer (Data Definition)

### Fields (User Input)

Typed field definitions. Each type has only its relevant properties.

```yaml
model:
  fields:
    # Text field - only text-relevant properties
    firstName:
      type: "text"
      validation:
        required: true
        minLength: 2
        maxLength: 50
        pattern: "^[A-Za-z ]+$"
    
    # Email - inherits text + email validation
    email:
      type: "email"
      validation:
        required: true
    
    # Number - numeric properties
    quantity:
      type: "number"
      validation:
        min: 0
        max: 1000
        integer: true
    
    # Select - selection properties
    country:
      type: "select"
      options:
        source: "static"  # or "api" or "master"
        values: ["India", "USA", "UK"]
      multi: false
    
    # Date - date properties
    birthDate:
      type: "date"
      format: "DD/MM/YYYY"
      validation:
        maxOffset: { value: 0, unit: "day" }  # Past dates only
    
    # File - file properties
    photo:
      type: "file"
      accept: ["image/*"]
      maxSize: "5MB"
      capture: "camera"
    
    # Location - location properties
    siteLocation:
      type: "location"
      geoTagging: true
      manualPick: true
    
    # Group (object) - nested fields
    address:
      type: "group"
      fields:
        street: { type: "text" }
        city: { type: "text" }
        pincode: { type: "text", validation: { pattern: "^[0-9]{6}$" } }
    
    # Repeater (array) - repeating rows
    familyMembers:
      type: "repeater"
      item:
        type: "group"
        fields:
          name: { type: "text", validation: { required: true } }
          relation: { type: "select", options: { values: ["Spouse", "Child"] } }
      validation:
        minItems: 0
        maxItems: 10
```

### Variables (Non-User Data)

Separate storage for computed/temporary values.

```yaml
model:
  variables:
    # Page-scoped (reset on page change)
    _tempSubtotal:
      type: "number"
      scope: "page"
    
    # Form-scoped (persist across pages)
    _sessionId:
      type: "string"
      scope: "form"
      computed: "uuid()"
    
    # Derived from API
    _priceFromApi:
      type: "number"
      scope: "form"
```

---

## 2. UI Layer (Presentation)

### Pages

Native multi-page support.

```yaml
ui:
  pages:
    - id: "personal"
      title: "Personal Information"
      description: "Basic details"
      fields:
        - "firstName"
        - "lastName" 
        - "email"
        - "phone"
      navigation:
        next:
          condition: "model.email != null"
          label: "Continue"
        
    - id: "address"
      title: "Address"
      fields:
        - "address"  # References the group
      navigation:
        previous: true
        next: true
        skip:
          condition: "model.sameAsRegistered == true"
          
    - id: "review"
      title: "Review & Submit"
      type: "summary"  # Special page type
      submit:
        label: "Submit Application"
```

### Layout

Explicit layout control.

```yaml
ui:
  layout:
    # Default layout for all pages
    default:
      type: "stack"
      spacing: 16
      
    # Page-specific overrides
    pages:
      personal:
        type: "grid"
        columns: 2
        rows:
          - ["firstName", "lastName"]
          - ["email", "phone"]
          - ["birthDate", "."]  # . = empty cell
          
    # Field-specific layout
    fields:
      address:
        type: "card"
        collapsible: true
        defaultExpanded: false
```

### Components

Reusable UI patterns.

```yaml
ui:
  components:
    # Define reusable component
    AddressBlock:
      type: "group"
      layout:
        type: "stack"
      fields:
        street: 
          type: "text"
          ui: { multiline: true, rows: 2 }
        city:
          type: "text"
        state:
          type: "select"
          options: { source: "master", masterId: "states" }
        pincode:
          type: "text"
          validation: { pattern: "^[0-9]{6}$" }
          
# Usage in fields
model:
  fields:
    homeAddress:
      $ref: "#/ui/components/AddressBlock"
    officeAddress:
      $ref: "#/ui/components/AddressBlock"
```

### Theme

Centralized styling.

```yaml
ui:
  theme:
    colors:
      primary: "#007AFF"
      secondary: "#5856D6"
      success: "#34C759"
      warning: "#FF9500"
      error: "#FF3B30"
      background: "#F2F2F7"
      surface: "#FFFFFF"
      text: "#000000"
      textSecondary: "#8E8E93"
      
    typography:
      fontFamily: "SF Pro"
      sizes:
        h1: 28
        h2: 22
        h3: 18
        body: 16
        caption: 14
        
    spacing:
      xs: 4
      sm: 8
      md: 16
      lg: 24
      xl: 32
      
    borderRadius:
      sm: 4
      md: 8
      lg: 16
      
    shadows:
      sm: "0 1px 2px rgba(0,0,0,0.1)"
      md: "0 4px 8px rgba(0,0,0,0.1)"
```

### Field UI Configuration

UI-specific settings separate from data model.

```yaml
ui:
  fields:
    firstName:
      label: "First Name"
      placeholder: "Enter your first name"
      hint: "As it appears on your ID"
      icon: "person"
      
    email:
      label: "Email Address"
      placeholder: "you@example.com"
      hint: "We'll send confirmation here"
      keyboard: "email"
      
    quantity:
      label: "Quantity"
      prefix: "Qty:"
      suffix: "units"
      stepper: true  # Show +/- buttons
      
    country:
      label: "Country"
      searchable: true
      layout: "dropdown"  # or "radio" or "chips"
      
    photo:
      label: "Profile Photo"
      cameraHint: "Position your face in the frame"
      showPreview: true
```

---

## 3. Logic Layer (Behavior)

### Computed Fields

Clear calculation definitions.

```yaml
logic:
  computed:
    # Simple calculation
    fullName:
      formula: "concat(model.firstName, ' ', model.lastName)"
      dependencies: ["firstName", "lastName"]
      
    # Conditional calculation
    total:
      formula: "model.subtotal * (1 - model.discount / 100)"
      dependencies: ["subtotal", "discount"]
      
    # Array aggregation
    itemsTotal:
      formula: "sum(model.items, 'price')"
      dependencies: ["items"]
      
    # With conditions
    shippingCost:
      formula: |
        if (model.total > 1000) {
          return 0;
        } else if (model.country == 'India') {
          return 50;
        } else {
          return 200;
        }
      dependencies: ["total", "country"]
```

### Validations

Form-level and cross-field validations.

```yaml
logic:
  validations:
    # Cross-field validation
    dateRange:
      condition: "model.endDate > model.startDate"
      message: "End date must be after start date"
      fields: ["startDate", "endDate"]
      
    # Conditional validation
    companyRequired:
      condition: "model.employmentType == 'Employed'"
      validate:
        field: "companyName"
        required: true
        message: "Company name required for employed applicants"
        
    # Async validation
    emailUnique:
      field: "email"
      async: true
      api: "validateEmail"
      debounce: 500
      message: "Email already registered"
```

### Effects (Side Effects)

Actions triggered by events.

```yaml
logic:
  effects:
    # On field change
    onStateChange:
      trigger: { field: "state", event: "change" }
      actions:
        - clear: ["district", "city"]
        - fetch: { api: "getDistricts", params: { stateId: "model.state" } }
        
    # On page enter
    onAddressPageEnter:
      trigger: { page: "address", event: "enter" }
      actions:
        - fetch: { api: "getStates" }
        
    # On form submit
    beforeSubmit:
      trigger: { form: true, event: "beforeSubmit" }
      actions:
        - validate: { all: true }
        - compute: ["fullName", "total"]
        
    # Conditional effect
    autoFillProfile:
      trigger: { field: "useProfile", event: "change" }
      condition: "model.useProfile == true"
      actions:
        - copy: 
            from: "user.profile"
            to: ["firstName", "lastName", "email", "phone"]
```

### Visibility Rules

Clear, declarative visibility.

```yaml
logic:
  visibility:
    # Simple condition
    middleName:
      visible: "model.hasMiddleName == true"
      
    # Role-based
    adminSection:
      visible: "user.role == 'admin'"
      
    # Complex condition
    discountField:
      visible: "model.customerType == 'Premium' && model.total > 1000"
      
    # Page-level
    pages:
      address:
        skip: "model.sameAsRegistered == true"
```

---

### Cascading Fields (Option Filter)

> **See [OPTION_FILTER Deep Analysis](./option-filter-analysis.md) for complete behavior spec.**

Explicit cascade configuration with defined behaviors.

```yaml
logic:
  cascades:
    locationCascade:
      # Define the chain
      chain: ["state", "district", "block", "village"]
      
      # What happens when parent changes
      onParentChange: "clear"  # clear | keep | validate
      
      # Cascade clearing
      cascadeDownstream: true
      
      # What to show when parent is empty
      emptyParentBehavior: "disable"  # disable | showAll | showNone
      emptyParentHint: "Select {parentLabel} first"
      
      # Loading states
      showLoadingState: true
      
      # No results handling
      noMatchBehavior:
        message: "No {fieldLabel} found for selected {parentLabel}"
        allowManualEntry: false
```

**Alternative: Per-field cascade config**

```yaml
fields:
  district:
    type: "select"
    options:
      masterRef: "locations"
      column: "d"
      
      # Filter configuration
      filter:
        parentField: "state"
        parentColumn: "s"
        
        # Cascade behavior
        onParentChange: "clear"
        cascadeDownstream: true
        
        # Empty parent
        emptyParentBehavior: "disable"
        emptyParentHint: "Select state first"
        
        # Multi-parent (AND/OR)
        # logic: "AND"  # For multiple parents
        
      # Loading UX
      loadingText: "Loading districts..."
      noMatchText: "No districts found"
```

**Defined behaviors:**

| Scenario | Behavior |
|----------|----------|
| Parent cleared | Clear this field + all downstream |
| Parent changed | Clear if value invalid, else keep |
| Parent empty | Disable field, show hint |
| Filter loading | Show spinner, disable input |
| No matches | Show message, optionally allow manual |
| Race condition | Cancel stale requests, use latest |

---

## 4. Integrations Layer

### API Definitions

Generic API integration.

```yaml
integrations:
  apis:
    # GET request
    getStates:
      url: "${env.API_BASE}/locations/states"
      method: "GET"
      cache: 3600  # seconds
      response:
        mapping:
          states: "$.data[*].name"
          
    # GET with params
    getDistricts:
      url: "${env.API_BASE}/locations/districts"
      method: "GET"
      params:
        stateId: "{{stateId}}"
      response:
        mapping:
          districts: "$.data[*].name"
          
    # POST request
    validateEmail:
      url: "${env.API_BASE}/validate/email"
      method: "POST"
      body:
        email: "{{email}}"
      response:
        valid: "$.isAvailable"
        message: "$.message"
        
    # Fetch for calculation
    getProductPrice:
      url: "${env.PRICING_API}/products/{{productId}}/price"
      method: "GET"
      response:
        mapping:
          _priceFromApi: "$.price"
          _stockAvailable: "$.inventory"
```

### Master Data

> **See [Master Data Strategy](./master-data-strategy.md) for complete solution.**

Centralized master registry with intelligent caching.

```yaml
integrations:
  masters:
    # Declare ONCE at form level, all fields share
    locations:
      id: "70311147-2fcc-489c-9981-8f374361a229"
      name: "India Locations"
      
      # Loading strategy
      strategy: "lazy"  # eager | lazy | onDemand
      
      # Caching
      cache:
        storage: "indexedDB"
        ttl: 86400  # 24 hours
        compression: true
        
      # Partition large datasets
      partitioning:
        enabled: true
        partitionBy: "s"  # State column
        maxCachedPartitions: 5
        
      # Version tracking for sync
      versioning:
        enabled: true
        checkInterval: 3600
        
      # What to fetch
      columns: ["s", "d", "b", "v"]
      indexes: ["s", "d", "b"]  # Fast filtering
      
    products:
      id: "product-master-uuid"
      strategy: "onDemand"  # Search-based, not preloaded
      searchable: true
      searchFields: ["name", "sku", "category"]
```

**Key improvements:**
- Single fetch per master (not per field)
- Partitioning for large datasets (90k → 2.5k per partition)
- Multi-level cache (memory → IndexedDB → server)
- Version-aware sync with delta updates
- LRU eviction for memory management

**Field reference syntax:**
```yaml
fields:
  state:
    type: "select"
    options:
      masterRef: "locations"  # Reference, not inline config
      column: "s"
      distinct: true
      
  district:
    type: "select"
    options:
      masterRef: "locations"  # Same reference, shared data
      column: "d"
      filter:
        - field: "state"
          column: "s"
```

---

## 5. Access Layer

### Role Definitions

```yaml
access:
  roles:
    - id: "field_agent"
      label: "Field Agent"
    - id: "supervisor"
      label: "Supervisor"
    - id: "admin"
      label: "Administrator"
```

### Access Rules

```yaml
access:
  rules:
    # Field-level access
    fields:
      salary:
        visible: ["admin", "hr"]
        editable: ["admin"]
        
      status:
        visible: ["*"]  # All roles
        editable: ["supervisor", "admin"]
        
    # Page-level access
    pages:
      adminSettings:
        visible: ["admin"]
        
    # Form-level access
    form:
      create: ["field_agent", "supervisor", "admin"]
      edit: ["supervisor", "admin"]
      delete: ["admin"]
```

---

## 6. Static Pages Support

For non-form content.

```yaml
schema:
  version: "2.0.0"
  type: "page"  # Not a form
  
  meta:
    id: "about-page"
    name: "About Us"
    
  ui:
    layout:
      type: "stack"
      spacing: 24
      
    content:
      - type: "hero"
        title: "About Our Company"
        subtitle: "Building the future of work"
        image: "hero-bg.jpg"
        
      - type: "text"
        content: |
          We are a leading provider of enterprise solutions...
        style:
          fontSize: 16
          lineHeight: 1.6
          
      - type: "cards"
        layout: "grid"
        columns: 3
        items:
          - icon: "rocket"
            title: "Our Mission"
            text: "..."
          - icon: "users"
            title: "Our Team"
            text: "..."
          - icon: "globe"
            title: "Our Reach"
            text: "..."
            
      - type: "cta"
        title: "Ready to get started?"
        button:
          label: "Contact Us"
          action: { navigate: "/contact" }
```

---

## 7. Dashboard Support

For data visualization pages.

```yaml
schema:
  version: "2.0.0"
  type: "dashboard"
  
  meta:
    id: "sales-dashboard"
    name: "Sales Dashboard"
    
  data:
    sources:
      dailySales:
        api: "getDailySales"
        refresh: 300  # seconds
        
      topProducts:
        api: "getTopProducts"
        
  ui:
    layout:
      type: "grid"
      columns: 12
      gap: 16
      
    widgets:
      - type: "metric"
        title: "Total Sales"
        value: "data.dailySales.total"
        format: "currency"
        trend: "data.dailySales.trend"
        span: 3
        
      - type: "chart"
        title: "Sales Trend"
        chartType: "line"
        data: "data.dailySales.history"
        x: "date"
        y: "amount"
        span: 6
        
      - type: "table"
        title: "Top Products"
        data: "data.topProducts"
        columns:
          - field: "name"
            label: "Product"
          - field: "sales"
            label: "Sales"
            format: "number"
        span: 12
```

---

## 8. Versioning & Migration

```yaml
schema:
  version: "2.1.0"
  
  migrations:
    "2.0.0":
      # From 2.0.0 to 2.1.0
      - rename:
          from: "fname"
          to: "firstName"
      - transform:
          field: "phone"
          formula: "'+91' + value.replace(/[^0-9]/g, '')"
      - addField:
          name: "middleName"
          default: ""
      - removeField:
          name: "legacyField"
```

---

## 9. Type Definitions

For tooling and validation.

```typescript
// TypeScript interfaces for schema validation

interface SchemaV2 {
  version: string;
  type: "form" | "page" | "wizard" | "dashboard";
  meta: SchemaMeta;
  model?: ModelDefinition;
  ui: UIDefinition;
  logic?: LogicDefinition;
  integrations?: IntegrationsDefinition;
  access?: AccessDefinition;
}

interface FieldDefinition {
  type: FieldType;
  validation?: FieldValidation;
}

type FieldType = 
  | TextFieldDef
  | NumberFieldDef
  | SelectFieldDef
  | DateFieldDef
  | FileFieldDef
  | LocationFieldDef
  | GroupFieldDef
  | RepeaterFieldDef;

interface TextFieldDef {
  type: "text" | "email" | "phone" | "url";
  validation?: {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    pattern?: string;
  };
}

interface NumberFieldDef {
  type: "number" | "currency" | "percentage";
  validation?: {
    required?: boolean;
    min?: number;
    max?: number;
    integer?: boolean;
  };
}

// ... etc
```

---

## Migration Strategy

### Phase 1: Parallel Support
- V2 schema processor alongside V1
- Transform V1 to V2 at runtime
- New forms use V2

### Phase 2: Tooling
- Schema editor supports V2
- Validation tools
- Migration utilities

### Phase 3: Gradual Migration
- Convert high-priority forms
- Keep V1 runtime for legacy
- Eventually deprecate V1

---

## Comparison

| Aspect | V1 | V2 |
|--------|----|----|
| Field definition | Fat SchemaProperty | Type-specific slim |
| Pages | Via sections | Native support |
| Variables | Shadow fields | Explicit variables |
| API integration | Limited | First-class |
| Page types | Forms only | Forms, pages, dashboards |
| Expressions | Strings | Structured or validated |
| Composition | None | Components |
| Layout | Limited | Full grid/flex |
| Actions | Coupled in fields | Separate logic layer |
| Versioning | None | Built-in |
| Theming | Scattered | Centralized |
| State | Implicit | Explicit |
| Access control | AccessMatrix | Clear rules |

---

## Next Steps

1. **Validate design** with team
2. **Build transformer** V1 → V2
3. **Implement runtime** for V2
4. **Create schema editor** with V2 support
5. **Migrate pilot forms**
6. **Document migration guide**

