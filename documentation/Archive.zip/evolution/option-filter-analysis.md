# OPTION_FILTER Deep Analysis

This document analyzes the current OPTION_FILTER implementation, identifies problems, and proposes ideal behavior.

---

## Current Implementation

### How OPTION_FILTER Works Today

```json
{
  "state": {
    "title": "State",
    "masterId": "location-master-uuid",
    "columnKey": "s",
    "dependentKeys": ["district"]
  },
  "district": {
    "title": "District",
    "masterId": "location-master-uuid",
    "columnKey": "d",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "state"
      }
    }],
    "dependentKeys": ["block"]
  },
  "block": {
    "title": "Block",
    "masterId": "location-master-uuid",
    "columnKey": "b",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "district"
      }
    }]
  }
}
```

### Flow Diagram

```
User selects State = "Maharashtra"
         │
         ▼
dependentKeys triggers district predicate
         │
         ▼
OPTION_FILTER runs on district
         │
         ▼
Filter master data: WHERE s = "Maharashtra"
         │
         ▼
District dropdown updates with filtered options
         │
         ▼
(User selects District = "Mumbai")
         │
         ▼
dependentKeys triggers block predicate
         │
         ▼
Block dropdown updates
```

---

## Current Problems

### Problem 1: Undefined Behavior on Parent Clear

**Scenario:** User has selected State → District → Block, then clears State.

**Current behavior:** Undefined / inconsistent

| Platform | Observed Behavior | Issue |
|----------|-------------------|-------|
| Android | District keeps old value | Orphaned value - invalid state |
| iOS | ? | ? |
| Web | ? | ? |

**Questions not answered by schema:**
- Should District clear when State clears?
- Should District show all options or empty options?
- Should Block also cascade-clear?
- What if District value is still valid under new State selection?

---

### Problem 2: No Cascade Clear Definition

**Scenario:** 4-level cascade: State → District → Block → Village

User changes State. What happens?

**Option A: Clear All Downstream**
```
State: Maharashtra → Karnataka
District: Mumbai → (cleared)
Block: Andheri → (cleared)
Village: Versova → (cleared)
```

**Option B: Keep Values, Validate Later**
```
State: Maharashtra → Karnataka
District: Mumbai (orphaned - no longer valid)
Block: Andheri (orphaned)
Village: Versova (orphaned)
```

**Current schema has no way to specify preference.**

---

### Problem 3: Race Conditions

**Scenario:** User rapidly changes State multiple times.

```
T0: Select "Maharashtra"  → Triggers district filter (async)
T1: Select "Karnataka"    → Triggers district filter (async)
T2: First request returns → Shows Maharashtra districts
T3: Second request returns → Shows Karnataka districts
```

**Problems:**
- UI flickers
- Wrong options might show momentarily
- If user selected during T2, selection could be invalid

---

### Problem 4: Validation of Orphaned Values

**Scenario:** Form is saved with State=Maharashtra, District=Mumbai. 
Later, master data changes and Mumbai is no longer under Maharashtra.

**On form load:**
- District shows "Mumbai" but it's not in filtered options
- Is this valid? Should it error? Should it clear?

**No schema mechanism to handle this.**

---

### Problem 5: Empty Parent Handling

**Scenario:** District has OPTION_FILTER on State. State is empty.

**Current behaviors:**
| Setting | Behavior |
|---------|----------|
| No condition | Shows all options (unfiltered) |
| With condition | Depends on condition |

**Problem:** Inconsistent. Some forms want "show all", others want "show none until parent selected".

---

### Problem 6: Multiple Parent Dependencies

**Scenario:** Field filters on TWO parents.

```json
{
  "product": {
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "category"
      }
    }, {
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "brand"
      }
    }]
  }
}
```

**Questions:**
- Are filters AND'd or OR'd?
- What if category is set but brand is empty?
- Order of evaluation?

**Schema doesn't clarify.**

---

### Problem 7: Loading States

**Scenario:** Master data has 50,000 records. Filtering takes 2 seconds.

**Current state:** No way to indicate:
- "Filtering in progress"
- "X options found"
- "No matching options"

User clicks dropdown and sees stale options.

---

## Ideal Behavior Specification

### 1. Cascade Clear Policy

**Schema should specify:**

```yaml
cascadePolicy: "clear" | "keep" | "validate"
```

| Policy | Behavior |
|--------|----------|
| `clear` | When parent changes, clear this field and all downstream |
| `keep` | Keep value, validate on submit |
| `validate` | Keep value, show error if invalid |

**Default recommendation:** `clear`

**Example:**

```json
{
  "district": {
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "state",
        "onParentChange": "clear",
        "cascadeDownstream": true
      }
    }]
  }
}
```

---

### 2. Empty Parent Behavior

**Schema should specify:**

```yaml
emptyParentBehavior: "showAll" | "showNone" | "disable"
```

| Behavior | What Happens |
|----------|--------------|
| `showAll` | Show all options when parent is empty |
| `showNone` | Show empty dropdown (with hint) |
| `disable` | Disable field until parent selected |

**Example:**

```json
{
  "district": {
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "state",
        "emptyParentBehavior": "disable",
        "emptyParentHint": "Please select a state first"
      }
    }]
  }
}
```

---

### 3. Multi-Parent Filter

**Schema should specify:**

```yaml
multiParentLogic: "AND" | "OR"
```

**Example:**

```json
{
  "product": {
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "filters": [
          { "field": "category" },
          { "field": "brand" }
        ],
        "logic": "AND",
        "requireAll": false  // false = skip filter if field empty
      }
    }]
  }
}
```

---

### 4. Value Retention on Reselect

**Scenario:** User selects State=MH, District=Mumbai, then changes State=KA, then changes back to State=MH.

**Should District restore to Mumbai?**

```yaml
retainPreviousValue: true | false
```

If `true`, remember last valid value per parent selection.

---

### 5. Loading State Support

```yaml
loadingBehavior:
  showSpinner: true
  disableDuringLoad: true
  placeholder: "Loading options..."
```

---

### 6. No Match Behavior

What to show when filter returns zero options?

```yaml
noMatchBehavior:
  message: "No districts found for this state"
  allowClear: true
  showRefresh: false
```

---

## Proposed Ideal Flow

### User Clears Parent Field

```
User clears "State" field
         │
         ▼
Cascade policy check
         │
    ┌────┴────┐
    │         │
    ▼         ▼
  CLEAR     KEEP/VALIDATE
    │         │
    ▼         ▼
Clear District    Keep District value
Clear Block       Mark as "pending validation"
Clear Village     Show warning icon
    │         │
    ▼         ▼
Reset to empty   On submit: validate
parent behavior  against current options
```

### User Changes Parent Field

```
User changes "State" from Maharashtra to Karnataka
         │
         ▼
Check current District value
         │
         ▼
Is current District valid for Karnataka?
         │
    ┌────┴────┐
    │         │
    ▼         ▼
   YES        NO
    │         │
    ▼         ▼
Keep value   Apply cascadePolicy
             │
        ┌────┴────┐
        │         │
        ▼         ▼
      CLEAR     VALIDATE
        │         │
        ▼         ▼
    Clear      Show error
    District   "District not valid
               for Karnataka"
```

### Empty Parent → Selection Made

```
User selects "State" (was empty)
         │
         ▼
Trigger OPTION_FILTER on District
         │
         ▼
Show loading spinner
         │
         ▼
Filter completes
         │
         ▼
Enable District dropdown
         │
         ▼
Show "{N} districts available"
```

---

## Complete Proposed Schema

```json
{
  "state": {
    "title": "State",
    "type": "string",
    "description": "string_list",
    "masterId": "location-master-uuid",
    "columnKey": "s",
    "dependentKeys": ["district", "block", "village"]
  },
  
  "district": {
    "title": "District",
    "type": "string",
    "description": "string_list",
    "masterId": "location-master-uuid",
    "columnKey": "d",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "state",
        
        // NEW: Cascade behavior
        "onParentChange": "clear",
        "cascadeDownstream": true,
        
        // NEW: Empty parent handling
        "emptyParentBehavior": "disable",
        "emptyParentHint": "Select a state first",
        
        // NEW: Loading behavior
        "showLoadingState": true,
        
        // NEW: No results handling
        "noMatchMessage": "No districts found"
      }
    }],
    "dependentKeys": ["block", "village"]
  },
  
  "block": {
    "title": "Block",
    "type": "string",
    "description": "string_list",
    "masterId": "location-master-uuid",
    "columnKey": "b",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "district",
        "onParentChange": "clear",
        "cascadeDownstream": true,
        "emptyParentBehavior": "disable",
        "emptyParentHint": "Select a district first"
      }
    }],
    "dependentKeys": ["village"]
  },
  
  "village": {
    "title": "Village",
    "type": "string",
    "description": "string_list",
    "masterId": "location-master-uuid",
    "columnKey": "v",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "block",
        "onParentChange": "clear",
        "emptyParentBehavior": "disable",
        "emptyParentHint": "Select a block first"
      }
    }]
  }
}
```

---

## Summary of Issues & Solutions

| Issue | Current | Proposed |
|-------|---------|----------|
| Parent clear behavior | Undefined | `onParentChange: "clear"` |
| Cascade clearing | Manual | `cascadeDownstream: true` |
| Empty parent | Inconsistent | `emptyParentBehavior` |
| Loading indication | None | `showLoadingState` |
| No match message | None | `noMatchMessage` |
| Multi-parent logic | Ambiguous | `filters[]` with `logic` |
| Value retention | None | `retainPreviousValue` |
| Race conditions | Unhandled | Runtime debounce + cancellation |

---

## Implementation Recommendations

### Client Runtime

1. **Debounce** rapid parent changes (300ms)
2. **Cancel** in-flight filter requests when parent changes again
3. **Cache** filter results per parent value
4. **Atomic** cascade updates (batch all downstream clears)

### Validation

1. On submit, validate all filtered fields against current options
2. Flag orphaned values as errors
3. Provide "refresh options" action for stale data

### UX States

| State | UI |
|-------|-----|
| Parent empty | Disabled + hint |
| Loading | Spinner + "Loading..." |
| Options ready | Enabled + "{N} options" |
| No match | Disabled + error message |
| Invalid value | Warning icon + "Value no longer valid" |

