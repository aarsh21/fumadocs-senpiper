# Recipe: Repeating Sections

## The Problem

You need to collect multiple instances of the same data:
- Multiple family members
- Multiple line items in an order
- Multiple addresses
- Daily entries over a period

---

## Basic Repeating Section

### Schema Definition

```json
{
  "familyMembers": {
    "title": "Family Members",
    "type": "array",
    "description": "section",
    "items": {
      "type": "object",
      "properties": {
        "name": {
          "title": "Name",
          "type": "string",
          "description": "textfield"
        },
        "relation": {
          "title": "Relation",
          "type": "string",
          "description": "string_list",
          "enum": ["Spouse", "Child", "Parent", "Sibling", "Other"]
        },
        "age": {
          "title": "Age",
          "type": "number",
          "description": "number"
        }
      },
      "order": ["name", "relation", "age"]
    },
    "minRows": 1,
    "maxRows": 10
  }
}
```

**Key elements:**
- `type: "array"` - Makes it repeating
- `items` - Defines what each row contains
- `items.type: "object"` - Each row is an object
- `items.properties` - Fields in each row
- `minRows` / `maxRows` - Limits on entries

### Answer Structure

```json
{
  "familyMembers": [
    { "name": "Jane Doe", "relation": "Spouse", "age": 35 },
    { "name": "John Jr", "relation": "Child", "age": 8 },
    { "name": "Sarah", "relation": "Child", "age": 5 }
  ]
}
```

---

## Row Controls

### Add Button Label

```json
{
  "familyMembers": {
    "type": "array",
    "description": "section",
    "newRowLabel": "Add Family Member",
    "items": { ... }
  }
}
```

### Hide Add Button

```json
{
  "hideAddNewRowButton": true
}
```

### Row Limits

```json
{
  "minRows": 1,    // At least one entry required
  "maxRows": 10    // No more than 10 entries
}
```

### Immutable Row Count

Prevent adding/removing rows after initial creation:

```json
{
  "immutableRowCount": true
}
```

---

## Calculations Within Rows

### Per-Row Calculation

Using `$i` to reference current row:

```json
{
  "lineItems": {
    "type": "array",
    "items": {
      "type": "object",
      "properties": {
        "quantity": {
          "title": "Qty",
          "type": "number",
          "dependentKeys": ["amount"]
        },
        "rate": {
          "title": "Rate",
          "type": "number",
          "dependentKeys": ["amount"]
        },
        "amount": {
          "title": "Amount",
          "type": "number",
          "formulaKeys": ["quantity", "rate"],
          "predicates": [{
            "action": "CALC",
            "actionConfig": {
              "formula": "(this.lineItems[$i].quantity || 0) * (this.lineItems[$i].rate || 0)"
            }
          }],
          "accessMatrix": { "readOnly": true }
        }
      }
    }
  }
}
```

**Important:** Use `this.lineItems[$i].fieldName` to access fields in the current row.

---

## Sum Across All Rows

### Client-Side Sum

```json
{
  "grandTotal": {
    "title": "Grand Total",
    "type": "number",
    "predicates": [{
      "action": "CALC",
      "actionConfig": {
        "formula": "(this.lineItems || []).reduce((sum, item) => sum + (item.amount || 0), 0)"
      }
    }],
    "accessMatrix": { "readOnly": true }
  }
}
```

### Using ASYNC_CALC

For server-side aggregation:

```json
{
  "grandTotal": {
    "predicates": [{
      "action": "ASYNC_CALC",
      "actionConfig": {
        "operation": "SUM",
        "key": "amount"
      }
    }]
  }
}
```

---

## Pre-filled Rows

Start with predefined rows:

```json
{
  "checklist": {
    "type": "array",
    "items": {
      "properties": {
        "item": { "type": "string" },
        "checked": { "type": "boolean" }
      }
    },
    "accessMatrix": {
      "answer": [
        { "item": "Item 1", "checked": false },
        { "item": "Item 2", "checked": false },
        { "item": "Item 3", "checked": false }
      ]
    },
    "immutableRowCount": true
  }
}
```

Users can edit values but not add/remove rows.

---

## Row Headers

Show a summary in collapsed row headers:

```json
{
  "familyMembers": {
    "type": "array",
    "keysForRowHeader": ["name", "relation"],
    "items": { ... }
  }
}
```

This shows "Jane Doe - Spouse" as the row header when collapsed.

---

## Layout Options

### Table Layout

Display array as a table:

```json
{
  "lineItems": {
    "type": "array",
    "layout": "table",
    "items": { ... }
  }
}
```

### Card Layout

Each row as a card:

```json
{
  "entries": {
    "type": "array",
    "layout": "card",
    "items": { ... }
  }
}
```

### Accordion Layout

Collapsible rows:

```json
{
  "sections": {
    "type": "array",
    "layout": "accordion",
    "items": { ... }
  }
}
```

---

## Nested Repeating Sections

Arrays within arrays:

```json
{
  "orders": {
    "type": "array",
    "items": {
      "type": "object",
      "properties": {
        "orderNumber": { "type": "string" },
        "lineItems": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "product": { "type": "string" },
              "quantity": { "type": "number" }
            }
          }
        }
      }
    }
  }
}
```

**Answer structure:**
```json
{
  "orders": [
    {
      "orderNumber": "ORD-001",
      "lineItems": [
        { "product": "Widget", "quantity": 5 },
        { "product": "Gadget", "quantity": 3 }
      ]
    }
  ]
}
```

**Addressing nested arrays:**
```
this.orders[$i].orderNumber          // First level
this.orders[$i].lineItems[$j].product // Second level
```

---

## Conditional Fields Within Rows

Show/hide fields based on row values:

```json
{
  "entries": {
    "type": "array",
    "items": {
      "properties": {
        "type": {
          "title": "Type",
          "type": "string",
          "enum": ["Standard", "Custom"],
          "dependentKeys": ["customDescription"]
        },
        "customDescription": {
          "title": "Custom Description",
          "accessMatrix": { "visibility": "GONE" },
          "predicates": [{
            "condition": "this.entries[$i].type == 'Custom'",
            "action": "APPLY_ACCESS_MATRIX",
            "actionConfig": {
              "accessMatrix": { "visibility": "VISIBLE" }
            }
          }]
        }
      }
    }
  }
}
```

---

## Cascading Dropdowns Within Rows

```json
{
  "locations": {
    "type": "array",
    "items": {
      "properties": {
        "state": {
          "masterId": "location-master",
          "columnKey": "state",
          "dependentKeys": ["district"]
        },
        "district": {
          "masterId": "location-master",
          "columnKey": "district",
          "predicates": [{
            "action": "OPTION_FILTER",
            "actionConfig": {
              "field": "state"
            }
          }]
        }
      }
    }
  }
}
```

**Note:** The OPTION_FILTER automatically resolves to the current row's state.

---

## Excluded Fields When Copying Rows

When user duplicates a row, exclude certain fields:

```json
{
  "entries": {
    "type": "array",
    "excludedFieldsForCopiedRow": ["id", "timestamp", "status"],
    "items": { ... }
  }
}
```

---

## Pagination

For arrays with many rows:

```json
{
  "entries": {
    "type": "array",
    "allowPagination": true,
    "items": { ... }
  }
}
```

Related form setting:
```json
{
  "formSetting": {
    "enableSectionArrayPagination": true
  }
}
```

---

## Use Last Value

Pre-fill new rows with values from the previous row:

```json
{
  "entries": {
    "type": "array",
    "items": {
      "properties": {
        "date": {
          "useLastValue": true
        },
        "location": {
          "useLastValue": true
        }
      }
    }
  }
}
```

---

## Validation

### Required Array

```json
{
  "lineItems": {
    "type": "array",
    "minRows": 1,
    "accessMatrix": { "mandatory": true }
  }
}
```

### Required Fields in Each Row

```json
{
  "items": {
    "properties": {
      "name": {
        "accessMatrix": { "mandatory": true }
      }
    }
  }
}
```

---

## Common Issues

### Issue: Calculations not updating

**Cause:** Missing `$i` in formula
```json
// Wrong
"formula": "this.lineItems.quantity * this.lineItems.rate"

// Right
"formula": "this.lineItems[$i].quantity * this.lineItems[$i].rate"
```

### Issue: New rows don't have defaults

**Solution:** Set defaults in items schema
```json
{
  "items": {
    "properties": {
      "status": {
        "accessMatrix": { "answer": "New" }
      }
    }
  }
}
```

### Issue: Can't delete the last row

**Cause:** `minRows: 1` prevents deletion
```json
{
  "minRows": 0  // Allow empty array
}
```

---

## Real Example

From your codebase - agricultural production data:

```json
{
  "agr": {
    "title": "Agricultural Production",
    "type": "array",
    "items": {
      "type": "object",
      "properties": {
        "cr": {
          "title": "Crop",
          "type": "string",
          "description": "string_list"
        },
        "cu": {
          "title": "Cultivation Area",
          "type": "number"
        },
        "prod": {
          "title": "Production",
          "type": "number"
        },
        "am": {
          "title": "Amount",
          "type": "number"
        }
      }
    }
  }
}
```

**Answer:**
```json
{
  "agr": [
    { "cr": "Paddy", "cu": 0.3, "prod": 8.0, "am": 8000.0 },
    { "cr": "Vegetables", "cu": 0.2, "prod": 80.0, "am": 60000.0 }
  ]
}
```

