# Schema Properties Reference

This document provides a comprehensive reference for all SchemaProperty properties, organized by scope of applicability.

---

# Part 1: Universal Properties

These properties apply to **all field types**.

---

## Identity & Display

### title
**Type:** `string`  
**Required:** Yes

The human-readable label displayed to users.

```json
{ "title": "Customer Name" }
```

---

### type
**Type:** `string`  
**Required:** Yes  
**Values:** `"string"`, `"number"`, `"boolean"`, `"object"`, `"array"`

The data type determining how the value is stored.

| Value | Storage | Example Answer |
|-------|---------|----------------|
| `string` | Text | `"John Doe"` |
| `number` | Numeric | `42` or `3.14` |
| `boolean` | True/False | `true` |
| `object` | Nested structure | `{ "city": "Mumbai" }` |
| `array` | List | `[{ ... }, { ... }]` |

```json
{ "type": "string" }
```

---

### description
**Type:** `string`  
**Required:** Yes

The UI component type to render. See [Field Types](../concepts/field-types.md) for full list.

**Common values:**
- Text: `textfield`, `email`, `phone`, `richtext`
- Selection: `string_list`
- Number: `number`, `rating`, `progress`
- Date: `timestamp`, `date`, `time`, `duration`
- Media: `multimedia`
- Location: `location`, `geofence`
- Scanner: `qrcode`, `barcode`
- Structure: `section`, `form`
- Display: `label`

```json
{ "description": "textfield" }
```

---

### hint
**Type:** `string`  
**Required:** No

Help text displayed near the field to guide users.

```json
{ "hint": "Enter your full name as it appears on your ID" }
```

---

### placeholder
**Type:** `string`  
**Required:** No

Text shown inside empty input fields as a hint.

```json
{ "placeholder": "e.g., John Doe" }
```

---

### layout
**Type:** `string`  
**Required:** No

Visual variant of the field component.

**For `string_list`:**
| Value | Renders As |
|-------|------------|
| (none) | Dropdown picker |
| `radio` | Radio buttons |
| `checkbox` | Checkboxes |
| `small_pill` | Small pill buttons |
| `large_pill` | Large pill buttons |

**For `section`:**
| Value | Renders As |
|-------|------------|
| (none) | Grouped fields |
| `accordion` | Collapsible section |
| `expandable` | Starts collapsed |
| `collapsed` | Starts collapsed |
| `expanded` | Starts expanded |
| `tab` | Tab navigation |
| `card` | Card container |
| `table` | Table layout (arrays) |

**For `label`:**
| Value | Renders As |
|-------|------------|
| `h1`, `h2`, `h3` | Heading styles |
| `info` | Info callout |
| `warn` | Warning callout |
| `error` | Error callout |

```json
{ "layout": "radio" }
```

---

### webLayout
**Type:** `string`  
**Required:** No

Layout variant specifically for web rendering. Same values as `layout`.

```json
{ "webLayout": "table" }
```

---

### wrapStyle
**Type:** `string`  
**Required:** No  
**Values:** `"trim"`, `"wrap"`

How to handle long text in title and content.

```json
{ "wrapStyle": "wrap" }
```

---

## Structure (Objects & Arrays)

### properties
**Type:** `Map<string, SchemaProperty>`  
**Required:** For `type: "object"`

Child field definitions for object types. Keys become field identifiers.

```json
{
  "type": "object",
  "properties": {
    "firstName": { "title": "First Name", "type": "string" },
    "lastName": { "title": "Last Name", "type": "string" }
  }
}
```

---

### items
**Type:** `SchemaProperty`  
**Required:** For `type: "array"`

Schema for each element in an array.

```json
{
  "type": "array",
  "items": {
    "type": "object",
    "properties": { ... }
  }
}
```

---

### order
**Type:** `string[]`  
**Required:** No (but recommended for objects)

Display order of child fields. Keys not in order may be hidden.

```json
{ "order": ["firstName", "lastName", "email"] }
```

---

### required
**Type:** `string[]`  
**Required:** No

List of required child field keys (JSON Schema compatibility).

```json
{ "required": ["firstName", "email"] }
```

---

## Access Control

### accessMatrix
**Type:** `AccessMatrix`  
**Required:** No

Field-level access control. See [Visibility & Access](../concepts/visibility-access.md).

```json
{
  "accessMatrix": {
    "visibility": "VISIBLE",
    "mandatory": true,
    "readOnly": false,
    "roles": ["USER", "ADMIN"],
    "answer": "default value"
  }
}
```

**AccessMatrix properties:**

| Property | Type | Values | Purpose |
|----------|------|--------|---------|
| `visibility` | string | `VISIBLE`, `INVISIBLE`, `GONE` | Field visibility |
| `viewModeVisibility` | string | `VISIBLE`, `INVISIBLE`, `GONE` | Visibility in view mode |
| `mandatory` | boolean | true/false | Required for submission |
| `readOnly` | boolean | true/false | Prevent editing |
| `roles` | string[] | Role names | Who this applies to |
| `cdr` | string[] | Custom role names | Company-defined roles |
| `userIds` | UUID[] | User IDs | Specific users |
| `answer` | any | Default value | Pre-populated value |
| `defaultMediaName` | string | Filename | Default media filename |
| `userProfileDriven` | boolean | true/false | Auto-fill from user profile |

---

## Conditional Logic

### predicates
**Type:** `Predicate[]`  
**Required:** No

Conditional rules that control field behavior. See [Conditional Logic](../concepts/conditional-logic.md).

```json
{
  "predicates": [{
    "condition": "this.status == 'Active'",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": { ... }
  }]
}
```

**Predicate properties:**

| Property | Type | Purpose |
|----------|------|---------|
| `condition` | string | JavaScript expression (returns boolean) |
| `action` | string | Action type (CALC, OPTION_FILTER, etc.) |
| `actionConfig` | object | Action-specific configuration |
| `skipPredicateExecutionOnClient` | boolean | Only run on server |
| `skipPredicateExecutionOnServer` | boolean | Only run on client |

---

### dependentKeys
**Type:** `string[]`  
**Required:** No

Fields that should re-evaluate when this field changes. Essential for predicate triggering.

```json
{
  "title": "State",
  "dependentKeys": ["district", "city"]
}
```

When State changes, predicates on District and City run.

---

### formulaKeys
**Type:** `string[]`  
**Required:** No

Fields used in this field's CALC formula. Declares dependencies for calculation.

```json
{
  "title": "Total",
  "formulaKeys": ["price", "quantity"],
  "predicates": [{
    "action": "CALC",
    "actionConfig": { "formula": "this.price * this.quantity" }
  }]
}
```

---

## Validation

### pattern
**Type:** `string` (regex)  
**Required:** No

Regular expression for validating string input.

```json
{
  "pattern": "^[A-Za-z ]+$"
}
```

---

### validationMessage
**Type:** `string`  
**Required:** No

Error message shown when validation fails.

```json
{
  "validationMessage": "Name can only contain letters and spaces"
}
```

---

### minimum / maximum
**Type:** `number`  
**Required:** No

For numbers: Min/max allowed value.
For dates: Offset from now (combined with `timeUnit`).

```json
{
  "type": "number",
  "minimum": 0,
  "maximum": 100
}
```

---

### minSize / maxSize
**Type:** `integer`  
**Required:** No

For strings: Min/max character count.
For multimedia: Min/max file size in bytes.

```json
{ "maxSize": 5242880 }  // 5MB
```

---

### minRows / maxRows
**Type:** `integer`  
**Required:** No

For arrays: Min/max number of rows allowed.

```json
{
  "type": "array",
  "minRows": 1,
  "maxRows": 10
}
```

---

## Options & Enums

### enum
**Type:** `string[]`  
**Required:** No

Predefined list of selectable options.

```json
{
  "enum": ["Option A", "Option B", "Option C"]
}
```

---

### sortOptions
**Type:** `boolean`  
**Required:** No

Whether to sort enum options alphabetically.

```json
{ "sortOptions": true }
```

---

## Master Data

### masterId
**Type:** `UUID`  
**Required:** No

ID of the master data source (form or list).

```json
{ "masterId": "70311147-2fcc-489c-9981-8f374361a229" }
```

---

### masterName
**Type:** `string`  
**Required:** No

Display name of the master (for UI/debugging).

```json
{ "masterName": "Location Master" }
```

---

### masterType
**Type:** `string`  
**Required:** No

Type of master data source.

```json
{ "masterType": "FORM" }
```

---

### groupId
**Type:** `UUID`  
**Required:** No

Group ID for the master form (when masterType is FORM).

```json
{ "groupId": "3a88d200-5656-420d-a3b4-b4d756ca1729" }
```

---

### columnKey
**Type:** `string`  
**Required:** No

Field key in master data to use for values.

```json
{ "columnKey": "state" }
```

---

### columnName
**Type:** `string`  
**Required:** No

Display name of the master column.

```json
{ "columnName": "State Name" }
```

---

### searchableKeys
**Type:** `string[]`  
**Required:** No

Master data columns that can be searched.

```json
{ "searchableKeys": ["name", "code", "category"] }
```

---

### masterPreviewFields
**Type:** `string[]`  
**Required:** No

Additional master columns to show when selecting.

```json
{ "masterPreviewFields": ["description", "price"] }
```

---

### filterString
**Type:** `string`  
**Required:** No

JavaScript expression to filter master data rows.

```json
{ "filterString": "this.category == formAnswer.selectedCategory" }
```

---

### enableOfflineOptionFilterMaster
**Type:** `boolean`  
**Required:** No

Enable client-side filtering of cached master data.

```json
{ "enableOfflineOptionFilterMaster": true }
```

---

### enableOnlineMaster
**Type:** `boolean`  
**Required:** No

Fetch master data from server on-demand.

```json
{ "enableOnlineMaster": true }
```

---

### enableOnlineSearchableMaster
**Type:** `boolean`  
**Required:** No

Enable server-side search in master data.

```json
{ "enableOnlineSearchableMaster": true }
```

---

### disableOfflineMaster
**Type:** `boolean`  
**Required:** No

Disable offline caching of master data.

```json
{ "disableOfflineMaster": true }
```

---

## Localization

### localisationMap
**Type:** `Map<string, object>`  
**Required:** No

Translations for field properties by language.

```json
{
  "localisationMap": {
    "Hindi": {
      "title": "ग्राहक का नाम",
      "hint": "अपना पूरा नाम दर्ज करें"
    }
  }
}
```

---

### enumListLocalisationMap
**Type:** `Map<string, Map<string, string>>`  
**Required:** No

Translations for enum options.

```json
{
  "enumListLocalisationMap": {
    "Yes": { "Hindi": "हाँ" },
    "No": { "Hindi": "नहीं" }
  }
}
```

---

## Auto-Generation

### autoGenerate
**Type:** `boolean`  
**Required:** No

Enable auto-generation of field value.

```json
{ "autoGenerate": true }
```

---

### autoGenerateConfig
**Type:** `object`  
**Required:** No

Configuration for auto-generated values. See [Auto-Generated IDs](../recipes/auto-generated-ids.md).

```json
{
  "autoGenerateConfig": {
    "generateBeforePredicate": true,
    "components": [
      { "type": "literal", "value": "INV-" },
      { "type": "sequence", "format": "00000" }
    ]
  }
}
```

---

## Display Configuration

### titleDisplayConfiguration
**Type:** `FieldDisplayConfiguration`  
**Required:** No

Custom styling for the field title.

---

### viewModeConfiguration
**Type:** `FieldDisplayConfiguration`  
**Required:** No

Display configuration for view mode.

---

### fillModeConfiguration
**Type:** `FieldDisplayConfiguration`  
**Required:** No

Display configuration for fill/edit mode.

---

### formDisplayConfiguration
**Type:** `FieldDisplayConfiguration`  
**Required:** No

General form display configuration.

---

### prefixText / suffixText
**Type:** `string`  
**Required:** No

Text displayed before/after the field value.

```json
{
  "prefixText": "$",
  "suffixText": "USD"
}
```

---

## Miscellaneous Universal

### uri
**Type:** `string` (URL)  
**Required:** No

External URI associated with the field.

---

### primaryKeys
**Type:** `string[]`  
**Required:** No

Fields used to generate unique hash/document ID.

```json
{ "primaryKeys": ["customerId", "orderDate"] }
```

---

### previewFields
**Type:** `string[]`  
**Required:** No

Fields to show in preview/summary (chat bubbles, lists).

```json
{ "previewFields": ["name", "date", "amount"] }
```

---

### caseIdentifierKey
**Type:** `string`  
**Required:** No

Key used for case/record identification.

---

### clonedFieldKey
**Type:** `string`  
**Required:** No

Key of field this was cloned from.

---

### sqlTitle
**Type:** `string`  
**Required:** No

SQL-compatible column name for database tables.

```json
{ "sqlTitle": "customer_name" }
```

---

# Part 2: Field-Specific Properties

These properties only apply to specific field types.

---

## textfield / email / phone

### otpValidation
**Type:** `string`  
**Values:** `"REQUESTED"`, `"MANDATORY"`

Require OTP verification for this field.

```json
{ "otpValidation": "MANDATORY" }
```

---

### otpConfig
**Type:** `object`  
**Required:** No

Configuration for OTP validation.

---

### renderAsMd
**Type:** `boolean`  
**Required:** No

Render content as Markdown.

```json
{ "renderAsMd": true }
```

---

## number

### format
**Type:** `string`  
**Required:** No

Number display format (e.g., `"#,##0.00"` for currency).

```json
{ "format": "#,##0.00" }
```

---

### prefix / suffix
**Type:** `string`  
**Required:** No

Text before/after number (e.g., "$" or "kg").

```json
{
  "prefix": "$",
  "suffix": "USD"
}
```

---

## string_list (Selection Fields)

### allowWildcardSelect
**Type:** `boolean`  
**Required:** No

Allow selecting all options.

---

### hideSearchIcon
**Type:** `boolean`  
**Required:** No

Hide the search icon in dropdown.

---

### disableManualEntry
**Type:** `boolean`  
**Required:** No

Prevent typing custom values.

---

### selectAllButtonText
**Type:** `string`  
**Required:** No

Text for "select all" button.

---

## timestamp / date / time

### dateOnly
**Type:** `boolean`  
**Required:** No

Only pick date, no time component.

```json
{ "dateOnly": true }
```

---

### timeOnly
**Type:** `boolean`  
**Required:** No

Only pick time, no date component.

```json
{ "timeOnly": true }
```

---

### systemTime
**Type:** `boolean`  
**Required:** No

Auto-fill with current system date/time.

```json
{ "systemTime": true }
```

---

### generateSystemTimeAtServer
**Type:** `boolean`  
**Required:** No

Generate system time on server (for consistency).

```json
{ "generateSystemTimeAtServer": true }
```

---

### enableEventScheduling
**Type:** `boolean`  
**Required:** No

Allow scheduling as calendar event.

---

### format
**Type:** `string`  
**Required:** No

Date/time display format (Java date format).

```json
{ "format": "dd MMM yyyy HH:mm" }
```

Common formats:
- `dd/MM/yyyy` → 15/01/2024
- `MMM dd, yyyy` → Jan 15, 2024
- `HH:mm` → 14:30
- `hh:mm a` → 02:30 PM

---

### timeUnit
**Type:** `string`  
**Values:** `"DAY"`, `"WEEK"`, `"MONTH"`, `"YEAR"`, `"HOUR"`, `"MINUTE"`, `"SECOND"`

Unit for minimum/maximum date offsets.

```json
{
  "minimum": -7,
  "maximum": 30,
  "timeUnit": "DAY"
}
```
↑ Allows dates from 7 days ago to 30 days from now.

---

### timeDelta
**Type:** `integer`  
**Required:** No

Time offset value.

---

### period
**Type:** `string`  
**Values:** `"Today"`, `"Yesterday"`, `"MTD"`, `"WTD"`, `"YTD"`, `"Custom"`

Predefined date period.

---

## multimedia (Image/Video/Audio/Document)

### multimediaType
**Type:** `string`  
**Values:** `"image"`, `"video"`, `"audio"`, `"document"`, `"canvas"`

Type of media allowed.

```json
{ "multimediaType": "image" }
```

---

### disableFilepicker
**Type:** `boolean`  
**Required:** No

Disable file picker (camera only for images).

```json
{ "disableFilepicker": true }
```

---

### enableGeoTagging
**Type:** `boolean`  
**Required:** No

Embed GPS coordinates in image metadata.

```json
{ "enableGeoTagging": true }
```

---

### showGeoCoordinates
**Type:** `boolean`  
**Required:** No

Display GPS coordinates to user.

---

### enforceCameraFlash
**Type:** `boolean`  
**Required:** No

Force camera flash when capturing.

---

### cameraHint
**Type:** `string`  
**Required:** No

Hint text shown when camera is open.

```json
{ "cameraHint": "Hold the camera steady and ensure good lighting" }
```

---

### embedImageMetadata
**Type:** `boolean`  
**Required:** No

Include EXIF metadata in uploaded images.

---

### shouldNotAutoDismissCameraView
**Type:** `boolean`  
**Required:** No

Keep camera open after capture.

---

### multimediaConfig
**Type:** `object`  
**Required:** No

Additional multimedia configuration options.

---

### mediaInfoMetaDataFields
**Type:** `string[]`  
**Required:** No

Metadata fields to extract from media.

---

## location

### pickManually
**Type:** `boolean`  
**Required:** No

Allow manual pin placement on map.

```json
{ "pickManually": true }
```

---

### editable
**Type:** `boolean`  
**Required:** No

Allow editing location after capture.

```json
{ "editable": true }
```

---

### locationMandatory
**Type:** `boolean`  
**Required:** No

GPS coordinates are required (vs. address only).

---

### showGeoCoordinates
**Type:** `boolean`  
**Required:** No

Display latitude/longitude to user.

---

### locationFieldConfig
**Type:** `object`  
**Required:** No

Additional location field configuration.

---

### geocodeDataMapping
**Type:** `Map<string, string>`  
**Required:** No

Map geocode data to form fields.

```json
{
  "geocodeDataMapping": {
    "city": "address.city",
    "state": "address.state"
  }
}
```

---

## qrcode / barcode

### qrConfig
**Type:** `object`  
**Required:** No

QR code scanning configuration.

---

### scanDisplayValueForBarCode
**Type:** `boolean`  
**Required:** No

Show scanned barcode value.

---

## section (Object/Array Containers)

### newRowLabel
**Type:** `string`  
**Required:** No

Label for "add new row" button in arrays.

```json
{ "newRowLabel": "Add Family Member" }
```

---

### hideAddNewRowButton
**Type:** `boolean`  
**Required:** No

Hide the add row button.

---

### keysForRowHeader
**Type:** `string[]`  
**Required:** No

Fields to display in collapsed row header.

```json
{ "keysForRowHeader": ["name", "relation"] }
```

---

### immutableRowCount
**Type:** `boolean`  
**Required:** No

Prevent adding/removing rows.

```json
{ "immutableRowCount": true }
```

---

### excludedFieldsForCopiedRow
**Type:** `string[]`  
**Required:** No

Fields to clear when duplicating a row.

```json
{ "excludedFieldsForCopiedRow": ["id", "timestamp"] }
```

---

### allowPagination
**Type:** `boolean`  
**Required:** No

Enable pagination for large arrays.

---

### useLastValue
**Type:** `boolean`  
**Required:** No

Pre-fill new rows with previous row's values.

---

### rowHeaderDisplayConfiguration
**Type:** `object`  
**Required:** No

Styling for row headers.

---

### sectionArrayConfiguration
**Type:** `object`  
**Required:** No

Column width and layout configuration for array tables.

---

## rating

### maximum
**Type:** `integer`  
**Required:** No

Maximum rating value (e.g., 5 for 5 stars).

```json
{ "maximum": 5 }
```

---

## label (Display Only)

### inlineHint
**Type:** `boolean`  
**Required:** No

Show hint inline with label.

---

## group_member (User Selection)

### disableMasterDataForGroupMembershipSetting
**Type:** `boolean`  
**Required:** No

Disable master data for group member list.

---

## separated_input (Segmented Input)

### separatedInputConfiguration
**Type:** `object[]`  
**Required:** No

Configuration for each input segment.

```json
{
  "separatedInputConfiguration": [
    { "length": 1 },
    { "length": 1 },
    { "length": 1 },
    { "length": 1 }
  ]
}
```

---

## object_detection

### imageObjectDetectionConfigs
**Type:** `object[]`  
**Required:** No

Configuration for object detection.

---

### bypassValidationIfInvalid
**Type:** `boolean`  
**Required:** No

Allow submission even if detection fails.

---

## External Integrations

### remoteValidations
**Type:** `object[]`  
**Required:** No

External API validation configurations.

---

### remoteValidation
**Type:** `boolean`  
**Required:** No

Enable remote validation.

---

### externalEntityVerificationConfigs
**Type:** `object[]`  
**Required:** No

Configuration for external verification (Aadhaar, PAN, etc.).

---

### externalMasterDetail
**Type:** `object`  
**Required:** No

External master data source configuration.

---

### hypervergeIntegrationConfig
**Type:** `object`  
**Required:** No

Configuration for Hyperverge integration (identity verification).

---

### captureIpAddress
**Type:** `boolean`  
**Required:** No

Capture client IP address.

---

## User Profile Integration

### userProfileDriven
**Type:** `boolean`  
**Required:** No

Auto-populate from logged-in user's profile.

```json
{ "userProfileDriven": true }
```

---

### userProfileKey
**Type:** `string`  
**Required:** No

Which user profile field to use.

```json
{ "userProfileKey": "department" }
```

---

### companyMasterId
**Type:** `UUID`  
**Required:** No

Company master ID for user profile mapping.

---

## Scoring

### scoringConfigs
**Type:** `Map<string, ScoringConfig>`  
**Required:** No

Scoring configuration for assessment forms.

---

## Master Population

### allowBypassOfMasterListPopulation
**Type:** `boolean`  
**Required:** No

Allow bypassing master list population.

---

### populateMasterDataInServer
**Type:** `boolean`  
**Required:** No

Populate master data on server side.

---

### overwriteMasterDataInServer
**Type:** `boolean`  
**Required:** No

Overwrite existing master data values on server.

---

### autoPopulateDependentKeys
**Type:** `boolean`  
**Required:** No

Auto-populate dependent fields.

---

### validateAgainstMasters
**Type:** `boolean`  
**Required:** No

Validate field value exists in master.

---

### masterCombinationKeys
**Type:** `string[]`  
**Required:** No

Fields for combined master validation.

---

## Web-Specific

### customWebFormLayouts
**Type:** `object[]`  
**Required:** No

Custom web form layout configurations.

---

### enableViewModeWebLayout
**Type:** `boolean`  
**Required:** No

Enable web layout in view mode.

---

### enableWebLayout
**Type:** `boolean`  
**Required:** No

Enable web-specific layout.

---

### hideSyncMasterStrip
**Type:** `boolean`  
**Required:** No

Hide master sync indicator on web.

---

## Bulk Upload

### disableAccessMatrixInBulkUpload
**Type:** `boolean`  
**Required:** No

Ignore access matrix during bulk upload.

---

## Reports

### formReportConfiguration
**Type:** `object`  
**Required:** No

Configuration for field in reports.

---

### showUrlInExcel
**Type:** `boolean`  
**Required:** No

Show URLs in Excel exports.

---

## Deprecated Properties

These properties are deprecated and should not be used in new schemas:

| Property | Replaced By |
|----------|-------------|
| `readOnly` | `accessMatrix.readOnly` |
| `hidden` | `accessMatrix.visibility` |
| `defaultValue` | `accessMatrix.answer` |
| `toBeForwarded` | Form-level assignee config |
| `self` | Assignee properties |
| `cameraOnly` | `disableFilepicker` |
| `appendOnly` | Use predicates |

---

# Part 3: Form-Level Properties

These properties exist on `FormSchema`, not on individual fields.

---

## Identity

| Property | Type | Purpose |
|----------|------|---------|
| `groupId` | UUID | Organization/workspace ID |
| `formId` | UUID | Unique form identifier |
| `companyId` | UUID | Company ID (multi-tenant) |
| `name` | string | Display name |

---

## Behavior Flags

| Property | Type | Default | Purpose |
|----------|------|---------|---------|
| `adminOnly` | boolean | false | Only admins can fill |
| `isPublic` | boolean | false | Publicly accessible |
| `master` | boolean | false | Used as master data |
| `linkableOnly` | boolean | false | Must be linked to another form |
| `disableDelete` | boolean | false | Prevent answer deletion |
| `updatable` | boolean | true | Allow editing answers |
| `chatDisabled` | boolean | false | Disable chat/notifications |
| `hidden` | boolean | false | Hide form in lists |
| `task` | boolean | false | Treat as task |

---

## Access

| Property | Type | Purpose |
|----------|------|---------|
| `initAccessMatrices` | AccessMatrix[] | Access for new submissions |
| `updateAccessMatrices` | AccessMatrix[] | Access for editing |

---

## Relationships

| Property | Type | Purpose |
|----------|------|---------|
| `parentSchemaIdentifier` | FormSchemaIdentifier | Parent form reference |
| `childSchemaIdentifiers` | FormSchemaIdentifier[] | Child form references |
| `linkableFormDetails` | LinkableFormDetail[] | Forms that can be linked |

---

## Workflow

| Property | Type | Purpose |
|----------|------|---------|
| `workflowId` | UUID | Associated workflow |
| `statuses` | string[] | Available statuses |
| `priorities` | string[] | Available priorities |

---

## Settings

| Property | Type | Purpose |
|----------|------|---------|
| `formSetting` | FormSetting | Form-level configuration |
| `primaryKeyConstraints` | Constraint[] | Uniqueness constraints |
| `localisationMap` | Map | Form name translations |

See FormSetting documentation for all available settings.

---

# Quick Reference by Use Case

## "I want to..."

| Goal | Property | Location |
|------|----------|----------|
| Make field required | `accessMatrix.mandatory` | Any field |
| Hide a field | `accessMatrix.visibility: "GONE"` | Any field |
| Show default value | `accessMatrix.answer` | Any field |
| Calculate value | `predicates` with `CALC` | Any field |
| Filter dropdown | `predicates` with `OPTION_FILTER` | string_list |
| Limit date range | `minimum`, `maximum`, `timeUnit` | timestamp/date |
| Restrict file size | `maxSize` | multimedia |
| Allow multiple selections | `type: "array"` | string_list |
| Create repeating rows | `type: "array"`, `items` | section |
| Add translations | `localisationMap` | Any field |
| Connect to master data | `masterId`, `columnKey` | string_list |
| Auto-generate ID | `autoGenerate`, `autoGenerateConfig` | textfield |
| Capture location | `description: "location"` | N/A |
| Upload files | `description: "multimedia"` | N/A |

