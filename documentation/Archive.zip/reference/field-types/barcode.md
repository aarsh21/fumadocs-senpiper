# barcode

## Purpose

Barcode scanner for capturing various barcode formats (UPC, EAN, Code128, etc.).

---

## Configuration

**Data Type:** `type: "string"`

**Description:** `description: "barcode"`

---

## Consumed Properties

| Property | Type | Purpose |
|----------|------|---------|
| `title` | string | Field label |
| `hint` | string | Help text |
| `accessMatrix` | object | Visibility, mandatory, readOnly |
| `predicates` | array | Conditional logic |
| `localisationMap` | object | Translations |
| `scanDisplayValueForBarCode` | boolean | Show scanned value |

> **Team: Please document** - What barcode formats are supported?

---

## Answer Structure

```json
{
  "productBarcode": "5901234123457"
}
```

---

## Example

```json
{
  "productBarcode": {
    "title": "Scan Product Barcode",
    "type": "string",
    "description": "barcode",
    "hint": "Scan the product barcode",
    "scanDisplayValueForBarCode": true
  }
}
```

---

## Supported Formats

> **Team: Please document** - Which formats are supported?

| Format | Supported? |
|--------|------------|
| UPC-A | ? |
| UPC-E | ? |
| EAN-13 | ? |
| EAN-8 | ? |
| Code 39 | ? |
| Code 128 | ? |
| ITF | ? |
| Codabar | ? |

---

## Behavior Notes

1. **Camera** - Opens camera in barcode scanning mode
2. **Multi-format** - Typically supports multiple barcode formats
3. **Display** - `scanDisplayValueForBarCode` shows the scanned value

---

## Platform Differences

> **Team: Please document any platform-specific behaviors**

