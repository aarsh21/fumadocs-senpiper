# timestamp / date / time

## Purpose

Date and time selection fields:
- `timestamp` - Full date and time
- `date` - Date only
- `time` - Time only

---

## Configuration

**Data Type:** `type: "string"`

**Description:** 
- `description: "timestamp"` - Date + Time
- `description: "date"` - Date only
- `description: "time"` - Time only

---

## Consumed Properties

### Standard Properties
| Property | Type | Purpose |
|----------|------|---------|
| `title` | string | Field label |
| `hint` | string | Help text |
| `accessMatrix` | object | Visibility, mandatory, readOnly |
| `predicates` | array | Conditional logic |
| `dependentKeys` | string[] | Fields that depend on this |
| `formulaKeys` | string[] | Fields used in calculations |
| `localisationMap` | object | Translations |

### Mode Properties
| Property | Type | Purpose |
|----------|------|---------|
| `dateOnly` | boolean | Show only date picker (for timestamp) |
| `timeOnly` | boolean | Show only time picker (for timestamp) |

### Format Properties
| Property | Type | Purpose | Example |
|----------|------|---------|---------|
| `format` | string | Display format | `"dd MMM yyyy HH:mm"` |

### System Time Properties
| Property | Type | Purpose |
|----------|------|---------|
| `systemTime` | boolean | Auto-fill with current time |
| `generateSystemTimeAtServer` | boolean | Generate on server (not client) |

### Range Properties
| Property | Type | Purpose | Example |
|----------|------|---------|---------|
| `minimum` | integer | Min offset from now | `-7` |
| `maximum` | integer | Max offset from now | `30` |
| `timeUnit` | string | Unit for offset | `"DAY"` |

### Event Properties
| Property | Type | Purpose |
|----------|------|---------|
| `enableEventScheduling` | boolean | Add to calendar |

### Other Properties
| Property | Type | Purpose |
|----------|------|---------|
| `timeDelta` | integer | Time delta value |
| `period` | string | Predefined period |
| `operator` | string | Comparison operator |

> **Team: Please verify** - How do `timeDelta`, `period`, and `operator` work?

---

## Layout Variants

> **Team: Please document** - What layout variants exist for date/time?

---

## Answer Structure

```json
{
  "appointmentTime": "2024-01-15T14:30:00Z",
  "birthDate": "1990-05-20",
  "meetingTime": "14:30"
}
```

> **Team: Please verify** - What is the exact storage format?

---

## Format Patterns

| Pattern | Example Output |
|---------|----------------|
| `dd/MM/yyyy` | 15/01/2024 |
| `MM/dd/yyyy` | 01/15/2024 |
| `yyyy-MM-dd` | 2024-01-15 |
| `dd MMM yyyy` | 15 Jan 2024 |
| `MMMM dd, yyyy` | January 15, 2024 |
| `HH:mm` | 14:30 (24-hour) |
| `hh:mm a` | 02:30 PM (12-hour) |
| `dd MMM yyyy HH:mm` | 15 Jan 2024 14:30 |

> **Team: Please verify** - What formats are supported?

---

## Time Units

| Value | Meaning |
|-------|---------|
| `DAY` | Days |
| `WEEK` | Weeks |
| `MONTH` | Months |
| `YEAR` | Years |
| `HOUR` | Hours |
| `MINUTE` | Minutes |
| `SECOND` | Seconds |

---

## Examples

### Date and Time
```json
{
  "appointmentTime": {
    "title": "Appointment Time",
    "type": "string",
    "description": "timestamp",
    "format": "dd MMM yyyy HH:mm",
    "accessMatrix": {
      "mandatory": true
    }
  }
}
```

### Date Only
```json
{
  "birthDate": {
    "title": "Date of Birth",
    "type": "string",
    "description": "date",
    "format": "dd/MM/yyyy"
  }
}
```

### Time Only
```json
{
  "startTime": {
    "title": "Start Time",
    "type": "string",
    "description": "time",
    "format": "HH:mm"
  }
}
```

### System Time (Auto-fill)
```json
{
  "createdAt": {
    "title": "Created At",
    "type": "string",
    "description": "timestamp",
    "systemTime": true,
    "format": "dd MMM yyyy HH:mm",
    "accessMatrix": {
      "readOnly": true
    }
  }
}
```

### Date Range Restriction
```json
{
  "visitDate": {
    "title": "Visit Date",
    "type": "string",
    "description": "date",
    "minimum": 0,
    "maximum": 30,
    "timeUnit": "DAY",
    "validationMessage": "Date must be within next 30 days"
  }
}
```

This allows only dates from today to 30 days in the future.

### Past Dates Only
```json
{
  "eventDate": {
    "title": "Event Date",
    "type": "string",
    "description": "date",
    "minimum": -365,
    "maximum": 0,
    "timeUnit": "DAY"
  }
}
```

Allows only dates from past year to today.

---

## Behavior Notes

1. **Date picker** - Native platform date/time picker
2. **systemTime** - Captures time when form loads or field becomes visible
3. **generateSystemTimeAtServer** - Ensures consistency in distributed scenarios
4. **Range validation** - Relative to current date/time
5. **Format** - Affects display only, storage format is consistent

---

## Date Calculations

### Days Between
```javascript
"Math.floor((new Date(this.endDate) - new Date(this.startDate)) / (1000 * 60 * 60 * 24))"
```

### Add Days
```javascript
"new Date(new Date(this.startDate).getTime() + (7 * 24 * 60 * 60 * 1000)).toISOString()"
```

### Age from Birthdate
```javascript
"Math.floor((Date.now() - new Date(this.birthDate)) / (365.25 * 24 * 60 * 60 * 1000))"
```

---

## Platform Differences

> **Team: Please document any platform-specific behaviors**

| Platform | Behavior |
|----------|----------|
| Android | ? |
| iOS | ? |
| Web | ? |

