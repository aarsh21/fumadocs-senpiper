# phone

## Purpose

Phone number input with phone keypad on mobile devices.

---

## Configuration

**Data Type:** `type: "string"`

**Description:** `description: "phone"`

---

## Consumed Properties

Same as [textfield](textfield.md), plus:

| Property | Type | Purpose |
|----------|------|---------|
| (inherits all textfield properties) | | |

> **Team: Please document** - Are there phone-specific properties (country code, formatting)?

---

## Answer Structure

```json
{
  "phone": "+919876543210"
}
```

---

## Example

### Basic Phone
```json
{
  "phone": {
    "title": "Mobile Number",
    "type": "string",
    "description": "phone",
    "accessMatrix": {
      "mandatory": true
    }
  }
}
```

### With Pattern (Indian Mobile)
```json
{
  "phone": {
    "title": "Mobile Number",
    "type": "string",
    "description": "phone",
    "pattern": "^\\+91[0-9]{10}$",
    "validationMessage": "Enter valid Indian mobile number (+91XXXXXXXXXX)"
  }
}
```

---

## Behavior Notes

1. **Keyboard** - Shows phone keypad on mobile
2. **Formatting** - May auto-format based on region
3. **Country code** - Typically include in pattern for validation

---

## Platform Differences

> **Team: Please document any platform-specific behaviors**

