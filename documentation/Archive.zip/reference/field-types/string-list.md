# string_list

## Purpose

Selection field for choosing from predefined options. Renders as dropdown, radio buttons, checkboxes, or pills based on configuration.

---

## Configuration

**Data Type:** 
- `type: "string"` for single select
- `type: "array"` for multi-select

**Description:** `description: "string_list"`

---

## Consumed Properties

### Standard Properties
| Property | Type | Purpose |
|----------|------|---------|
| `title` | string | Field label |
| `hint` | string | Help text |
| `accessMatrix` | object | Visibility, mandatory, readOnly |
| `predicates` | array | Conditional logic |
| `dependentKeys` | string[] | Fields that depend on this |
| `localisationMap` | object | Translations |

### Options Properties
| Property | Type | Purpose | Example |
|----------|------|---------|---------|
| `enum` | string[] | Static options list | `["Yes", "No"]` |
| `sortOptions` | boolean | Sort options alphabetically | `true` |
| `enumListLocalisationMap` | object | Option translations | See example |

### Layout Properties
| Property | Type | Purpose |
|----------|------|---------|
| `layout` | string | Visual variant (see below) |
| `webLayout` | string | Web-specific variant |

### Master Data Properties
| Property | Type | Purpose |
|----------|------|---------|
| `masterId` | UUID | Master data source ID |
| `masterName` | string | Master display name |
| `masterType` | string | Type of master (`"FORM"`) |
| `groupId` | UUID | Group ID for form master |
| `columnKey` | string | Column key for values |
| `columnName` | string | Column display name |
| `searchableKeys` | string[] | Searchable columns |
| `masterPreviewFields` | string[] | Preview columns |
| `filterString` | string | Filter expression |
| `enableOfflineOptionFilterMaster` | boolean | Client-side filtering |
| `enableOnlineMaster` | boolean | Server-side fetching |
| `enableOnlineSearchableMaster` | boolean | Server-side search |
| `disableOfflineMaster` | boolean | Disable offline cache |
| `masterFilterConfig` | object | Filter configuration |

### Selection Behavior Properties
| Property | Type | Purpose |
|----------|------|---------|
| `allowWildcardSelect` | boolean | Allow "select all" |
| `hideSearchIcon` | boolean | Hide search in dropdown |
| `disableManualEntry` | boolean | Prevent custom values |
| `selectAllButtonText` | string | "Select all" button text |

> **Team: Please verify** - Are there other properties specific to string_list?

---

## Layout Variants

| Value | Appearance | Best For |
|-------|------------|----------|
| (none) | Dropdown picker | Long option lists |
| `radio` | Radio buttons | 2-5 options, single select |
| `checkbox` | Checkboxes | Multi-select |
| `small_pill` / `smallPill` | Small pill buttons | Tags, compact selection |
| `large_pill` / `largePill` | Large pill buttons | Prominent options |

```json
{ "layout": "radio" }
```

---

## Answer Structure

### Single Select
```json
{
  "country": "India"
}
```

### Multi-Select (type: array)
```json
{
  "skills": ["JavaScript", "Python", "Go"]
}
```

---

## Examples

### Static Options (Dropdown)
```json
{
  "country": {
    "title": "Country",
    "type": "string",
    "description": "string_list",
    "enum": ["India", "USA", "UK", "Canada"],
    "accessMatrix": {
      "mandatory": true
    }
  }
}
```

### Radio Buttons
```json
{
  "gender": {
    "title": "Gender",
    "type": "string",
    "description": "string_list",
    "layout": "radio",
    "enum": ["Male", "Female", "Other"]
  }
}
```

### Multi-Select Checkboxes
```json
{
  "interests": {
    "title": "Interests",
    "type": "array",
    "description": "string_list",
    "layout": "checkbox",
    "enum": ["Sports", "Music", "Travel", "Technology"]
  }
}
```

### Master Data with Filter
```json
{
  "district": {
    "title": "District",
    "type": "string",
    "description": "string_list",
    "masterId": "70311147-2fcc-489c-9981-8f374361a229",
    "masterName": "Location Master",
    "masterType": "FORM",
    "columnKey": "d",
    "columnName": "District",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": {
        "field": "state"
      }
    }],
    "dependentKeys": ["block"],
    "enum": []
  }
}
```

### With Localization
```json
{
  "answer": {
    "title": "Response",
    "type": "string",
    "description": "string_list",
    "layout": "radio",
    "enum": ["Yes", "No"],
    "localisationMap": {
      "Hindi": {
        "title": "जवाब",
        "enum": ["हाँ", "नहीं"]
      }
    },
    "enumListLocalisationMap": {
      "Yes": { "Hindi": "हाँ" },
      "No": { "Hindi": "नहीं" }
    }
  }
}
```

---

## Behavior Notes

1. **Empty enum with master** - When using master data, set `"enum": []`
2. **OPTION_FILTER** - Requires `dependentKeys` on the source field
3. **Multi-select validation** - Use `type: "array"` with `minRows`/`maxRows` for selection limits
4. **Sorting** - `sortOptions: true` sorts alphabetically
5. **Value storage** - Always stores the **base value**, not localized text

---

## Common Patterns

### Cascading Dropdowns
```
State → District → Block → Village
```
Each level uses OPTION_FILTER to filter by the previous selection.

### Yes/No Radio
```json
{
  "layout": "radio",
  "enum": ["Yes", "No"]
}
```

### Dynamic Options from Master
Options populated from another form's answers.

---

## Platform Differences

> **Team: Please document any platform-specific behaviors**

| Platform | Behavior |
|----------|----------|
| Android | ? |
| iOS | ? |
| Web | ? |

