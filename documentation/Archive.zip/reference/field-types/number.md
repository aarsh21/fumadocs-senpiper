# number

## Purpose

Numeric input for quantities, amounts, measurements, and other numeric data. Supports integers and decimals.

---

## Configuration

**Data Type:** `type: "number"`

**Description:** `description: "number"`

---

## Consumed Properties

### Standard Properties
| Property | Type | Purpose |
|----------|------|---------|
| `title` | string | Field label |
| `hint` | string | Help text |
| `placeholder` | string | Placeholder text |
| `accessMatrix` | object | Visibility, mandatory, readOnly |
| `predicates` | array | Conditional logic |
| `dependentKeys` | string[] | Fields that depend on this |
| `formulaKeys` | string[] | Fields used in calculations |
| `localisationMap` | object | Translations |

### Validation Properties
| Property | Type | Purpose | Example |
|----------|------|---------|---------|
| `minimum` | number | Minimum value | `0` |
| `maximum` | number | Maximum value | `100` |
| `pattern` | string | Regex pattern | `"^[0-9]+$"` |
| `validationMessage` | string | Error message | `"Must be positive"` |

### Display Properties
| Property | Type | Purpose | Example |
|----------|------|---------|---------|
| `format` | string | Display format | `"#,##0.00"` |
| `prefix` | string | Text before value | `"$"` or `"₹"` |
| `suffix` | string | Text after value | `"kg"` or `"%"` |
| `prefixText` | string | Alt for prefix | Same as prefix |
| `suffixText` | string | Alt for suffix | Same as suffix |

> **Team: Please verify** - Are `prefix`/`suffix` and `prefixText`/`suffixText` the same?

---

## Layout Variants

### layout: "counter"
Shows increment/decrement buttons.

```json
{
  "layout": "counter"
}
```

> **Team: Please verify** - What other layout variants exist for number?

---

## Answer Structure

```json
{
  "quantity": 42,
  "price": 99.99
}
```

Stored as JavaScript number (integer or float).

---

## Examples

### Basic Number
```json
{
  "quantity": {
    "title": "Quantity",
    "type": "number",
    "description": "number",
    "accessMatrix": {
      "mandatory": true
    }
  }
}
```

### With Min/Max
```json
{
  "age": {
    "title": "Age",
    "type": "number",
    "description": "number",
    "minimum": 0,
    "maximum": 120,
    "validationMessage": "Age must be between 0 and 120"
  }
}
```

### Currency Format
```json
{
  "amount": {
    "title": "Amount",
    "type": "number",
    "description": "number",
    "format": "#,##0.00",
    "prefix": "₹",
    "minimum": 0
  }
}
```

### Percentage
```json
{
  "completion": {
    "title": "Completion %",
    "type": "number",
    "description": "number",
    "suffix": "%",
    "minimum": 0,
    "maximum": 100
  }
}
```

### Calculated Field
```json
{
  "total": {
    "title": "Total",
    "type": "number",
    "description": "number",
    "formulaKeys": ["quantity", "price"],
    "predicates": [{
      "action": "CALC",
      "actionConfig": {
        "formula": "(this.quantity || 0) * (this.price || 0)"
      }
    }],
    "accessMatrix": {
      "readOnly": true
    }
  }
}
```

---

## Format Patterns

| Pattern | Example Output | Use Case |
|---------|----------------|----------|
| `#` | `5` | Integer |
| `#.#` | `5.3` | One decimal |
| `#.##` | `5.35` | Two decimals |
| `#,##0` | `1,234` | Thousands separator |
| `#,##0.00` | `1,234.56` | Currency |
| `0.00` | `5.30` | Force 2 decimals |

> **Team: Please verify** - What format patterns are supported?

---

## Behavior Notes

1. **Keyboard** - Mobile shows numeric keypad
2. **Null handling** - Empty field may be `null` or `undefined`, use `(value || 0)` in formulas
3. **Decimals** - Allowed by default, use pattern `"^[0-9]+$"` to restrict to integers
4. **Min/Max** - Validated on blur and submit, doesn't prevent typing

---

## Common Calculations

### Sum
```javascript
"(this.a || 0) + (this.b || 0)"
```

### Percentage
```javascript
"(this.part / this.total) * 100"
```

### With Discount
```javascript
"this.price * (1 - this.discount / 100)"
```

---

## Platform Differences

> **Team: Please document any platform-specific behaviors**

| Platform | Behavior |
|----------|----------|
| Android | ? |
| iOS | ? |
| Web | ? |

