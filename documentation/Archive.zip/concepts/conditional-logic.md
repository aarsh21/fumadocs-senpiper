# Conditional Logic (Predicates)

## What Are Predicates?

Predicates are the heart of dynamic forms. They define rules that say:

> "When **this condition** is true, perform **this action** on this field."

Without predicates, forms are static—fields just sit there waiting for input. With predicates, forms come alive:
- Fields appear and disappear based on previous answers
- Values calculate automatically
- Options filter based on selections
- Validation adapts to context

---

## Anatomy of a Predicate

Every predicate has three parts:

```json
{
  "predicates": [{
    "condition": "this.country == 'India'",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": {
      "accessMatrix": {
        "visibility": "VISIBLE",
        "mandatory": true
      }
    }
  }]
}
```

| Part | Purpose | Required? |
|------|---------|-----------|
| `condition` | When should this run? (JavaScript expression) | Optional* |
| `action` | What action to perform | Required |
| `actionConfig` | Parameters for the action | Depends on action |

*If no condition is specified, the predicate always runs when triggered.

---

## The Predicate Lifecycle

Understanding when predicates run is crucial:

```
┌─────────────────────────────────────────────────────────────┐
│                    FORM LOADS                                │
│                        │                                     │
│                        ▼                                     │
│            All predicates evaluate                           │
│            (with current/empty answers)                      │
│                        │                                     │
└────────────────────────┼────────────────────────────────────┘
                         │
┌────────────────────────┼────────────────────────────────────┐
│                    USER EDITS FIELD                          │
│                        │                                     │
│                        ▼                                     │
│    Check: Is this field in any dependentKeys?                │
│                        │                                     │
│              ┌─────────┴─────────┐                          │
│              │                   │                           │
│              ▼                   ▼                           │
│             YES                  NO                          │
│              │                   │                           │
│              ▼                   ▼                           │
│    Run predicates of            Done                         │
│    dependent fields                                          │
│              │                                               │
│              ▼                                               │
│    For each predicate:                                       │
│    1. Evaluate condition                                     │
│    2. If true, execute action                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### The Dependency Chain

```json
{
  "state": {
    "title": "State",
    "dependentKeys": ["district", "fullAddress"]
  },
  "district": {
    "title": "District",
    "predicates": [{
      "action": "OPTION_FILTER",
      "actionConfig": { "field": "state" }
    }],
    "dependentKeys": ["fullAddress"]
  },
  "fullAddress": {
    "title": "Full Address",
    "predicates": [{
      "action": "CALC",
      "actionConfig": {
        "formula": "this.state + ', ' + this.district"
      }
    }]
  }
}
```

When user selects a State:
1. State's `dependentKeys` triggers: District, FullAddress
2. District's OPTION_FILTER runs → options update
3. FullAddress's CALC runs → value updates
4. If District changes due to filtering, its `dependentKeys` trigger again

---

## Action Types

### CALC - Calculate Value

**Purpose:** Compute a value and store it in this field.

**When to use:** Auto-calculated totals, concatenated strings, derived values.

```json
{
  "title": "Total Amount",
  "type": "number",
  "formulaKeys": ["quantity", "unitPrice", "discount"],
  "predicates": [{
    "action": "CALC",
    "actionConfig": {
      "formula": "this.quantity * this.unitPrice * (1 - this.discount/100)"
    }
  }]
}
```

**Important:** The formula's return value **replaces** the field's current value.

**Real example from your codebase:**
```json
{
  "title": "Location Key",
  "predicates": [{
    "action": "CALC",
    "actionConfig": {
      "formula": "this.s+'/'+this.di+'/'+this.bl+'/'+this.villa"
    }
  }]
}
```

---

### OPTION_FILTER - Filter Dropdown Options

**Purpose:** Filter the available options in a dropdown based on another field's value.

**When to use:** Cascading dropdowns (State → District → City).

```json
{
  "title": "District",
  "masterId": "location-master-uuid",
  "columnKey": "district",
  "predicates": [{
    "action": "OPTION_FILTER",
    "actionConfig": {
      "field": "state"
    }
  }]
}
```

**How it works:**
1. User selects "Maharashtra" in State field
2. OPTION_FILTER predicate triggers on District
3. System filters master data where State column = "Maharashtra"
4. District dropdown shows only matching districts

**Real example from your codebase:**
```json
{
  "title": "District",
  "masterId": "70311147-2fcc-489c-9981-8f374361a229",
  "masterName": "Location master",
  "columnKey": "d",
  "predicates": [{
    "action": "OPTION_FILTER",
    "actionConfig": {
      "field": "s"
    }
  }]
}
```

---

### APPLY_ACCESS_MATRIX - Change Field Access

**Purpose:** Dynamically change a field's visibility, mandatory status, or editability.

**When to use:** Show/hide fields based on conditions, make fields required conditionally.

```json
{
  "title": "Spouse Name",
  "predicates": [{
    "condition": "this.maritalStatus == 'Married'",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": {
      "accessMatrix": {
        "visibility": "VISIBLE",
        "mandatory": true
      }
    }
  }, {
    "condition": "this.maritalStatus != 'Married'",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": {
      "accessMatrix": {
        "visibility": "GONE"
      }
    }
  }]
}
```

**Access Matrix Options:**
| Property | Values | Effect |
|----------|--------|--------|
| `visibility` | `VISIBLE`, `INVISIBLE`, `GONE` | Show, hide (keep space), remove |
| `mandatory` | `true`, `false` | Required for submission |
| `readOnly` | `true`, `false` | View only |

**Note:** You often need **two predicates**—one for "when condition is true" and one for "when condition is false".

---

### VALIDATE - Custom Validation

**Purpose:** Run custom validation and show error messages.

**When to use:** Complex validation rules beyond simple required/pattern.

```json
{
  "title": "End Date",
  "predicates": [{
    "condition": "this.endDate <= this.startDate",
    "action": "VALIDATE",
    "actionConfig": {
      "errorMessage": "End date must be after start date"
    }
  }]
}
```

**With custom validation config:**
```json
{
  "predicates": [{
    "condition": "this.quantity > this.maxStock",
    "action": "VALIDATE",
    "actionConfig": {
      "useValidatePredicateConfig": true,
      "validatePredicateConfig": {
        "errorMessage": "Quantity exceeds available stock",
        "resultLayout": "INLINE",
        "allowSubmissionOnConditionFailure": false
      }
    }
  }]
}
```

---

### COPY - Copy Value from Another Field

**Purpose:** Copy a value from one field to another.

**When to use:** Default values, carrying forward answers.

```json
{
  "title": "Billing Address",
  "predicates": [{
    "condition": "this.sameAsShipping == true",
    "action": "COPY",
    "actionConfig": {
      "field": "shippingAddress"
    }
  }]
}
```

---

### ASYNC_CALC - Aggregation from Other Forms

**Purpose:** Calculate aggregates (sum, count, average) from another form's answers.

**When to use:** Dashboards, rollup calculations, cross-form totals.

```json
{
  "title": "Total Orders",
  "predicates": [{
    "action": "ASYNC_CALC",
    "actionConfig": {
      "formSchemaIdentifier": {
        "groupId": "...",
        "formSchemaId": "orders-form-id"
      },
      "filterCondition": "this.customerId == formAnswer.customerId",
      "key": "amount",
      "operation": "SUM"
    }
  }]
}
```

**Operations:**
- `SUM` - Add up all values
- `COUNT` - Count matching records
- `AVERAGE` - Calculate mean
- `MIN` - Find minimum
- `MAX` - Find maximum

---

### CONDITIONAL_FORMAT - Change Field Appearance

**Purpose:** Change how a field looks based on conditions.

**When to use:** Highlighting values, status indicators.

```json
{
  "predicates": [{
    "action": "CONDITIONAL_FORMAT",
    "actionConfig": {
      "conditionalFormatPredicateConfig": {
        "conditionalFormats": [
          {
            "condition": "this.status == 'Overdue'",
            "fieldDisplayConfiguration": {
              "backgroundColor": "#ffcccc",
              "textColor": "#cc0000"
            }
          }
        ]
      }
    }
  }]
}
```

---

### APPEND - Add to Array

**Purpose:** Append a value to an array field.

**When to use:** Building up a list based on actions.

```json
{
  "predicates": [{
    "condition": "this.addItem == true",
    "action": "APPEND",
    "actionConfig": {
      "appendPredicateConfig": {
        "appendExpression": "this.newItem"
      }
    }
  }]
}
```

---

### GEO_FENCE - Location Validation

**Purpose:** Validate that a location is within a defined boundary.

**When to use:** Ensuring field workers are at correct locations.

```json
{
  "predicates": [{
    "action": "GEO_FENCE",
    "actionConfig": {
      "geoFencePredicateConfig": {
        "centerLat": 19.0760,
        "centerLng": 72.8777,
        "radiusInMeters": 500
      }
    }
  }]
}
```

---

### FACE_MATCH - Biometric Validation

**Purpose:** Verify that captured photo matches a reference image.

**When to use:** Identity verification, attendance systems.

---

### CUSTOM_FUNCTION - Run Custom Code

**Purpose:** Execute custom JavaScript functions for complex logic.

**When to use:** Logic that doesn't fit other action types.

---

### JSON_CALC - JSON Manipulation

**Purpose:** Perform calculations on JSON structures.

**When to use:** Complex data transformations.

---

## Execution Control

### skipPredicateExecutionOnClient

```json
{
  "predicates": [{
    "action": "ASYNC_CALC",
    "skipPredicateExecutionOnClient": true,
    "actionConfig": { ... }
  }]
}
```

When `true`, this predicate only runs on the server. Useful for:
- Heavy calculations that would slow the UI
- Server-side validations
- Aggregations that need database access

### skipPredicateExecutionOnServer

```json
{
  "predicates": [{
    "action": "CALC",
    "skipPredicateExecutionOnServer": true,
    "actionConfig": { ... }
  }]
}
```

When `true`, this predicate only runs on the client. Useful for:
- UI-only calculations
- Temporary display values

---

## Best Practices

### 1. Always Define Both States

For visibility predicates, handle both conditions:

```json
// Bad - field stays in last state if condition becomes false
{
  "predicates": [{
    "condition": "this.showExtra == true",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": { "accessMatrix": { "visibility": "VISIBLE" } }
  }]
}

// Good - explicitly handle both states
{
  "predicates": [{
    "condition": "this.showExtra == true",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": { "accessMatrix": { "visibility": "VISIBLE" } }
  }, {
    "condition": "this.showExtra != true",
    "action": "APPLY_ACCESS_MATRIX",
    "actionConfig": { "accessMatrix": { "visibility": "GONE" } }
  }]
}
```

### 2. Use formulaKeys for CALC

Always declare which fields your formula uses:

```json
{
  "title": "Total",
  "formulaKeys": ["price", "quantity", "tax"],
  "predicates": [{
    "action": "CALC",
    "actionConfig": {
      "formula": "(this.price * this.quantity) + this.tax"
    }
  }]
}
```

This ensures the formula recalculates when any input changes.

### 3. Order Predicates Logically

When a field has multiple predicates, they run in order. Put critical validations first:

```json
{
  "predicates": [
    { "action": "VALIDATE", ... },  // Validate first
    { "action": "CALC", ... },       // Then calculate
    { "action": "APPLY_ACCESS_MATRIX", ... }  // Then adjust visibility
  ]
}
```

### 4. Handle Null Values

Formulas fail on null values. Add protection:

```json
{
  "formula": "(this.price || 0) * (this.quantity || 0)"
}
```

### 5. Keep Conditions Simple

Complex conditions are hard to debug. Split into multiple predicates if needed:

```json
// Hard to debug
{
  "condition": "(this.type == 'A' && this.status == 'Active') || (this.type == 'B' && this.level > 5)"
}

// Easier to understand
{
  "predicates": [
    {
      "condition": "this.type == 'A' && this.status == 'Active'",
      "action": "..."
    },
    {
      "condition": "this.type == 'B' && this.level > 5",
      "action": "..."
    }
  ]
}
```

---

## Debugging Predicates

### Predicate Not Running?

1. **Check dependentKeys** - Is this field listed in another field's `dependentKeys`?
2. **Check formulaKeys** - For CALC, are the source fields in `formulaKeys`?
3. **Check condition syntax** - Any typos or JavaScript errors?
4. **Check execution flags** - Is `skipPredicateExecutionOnClient` set?

### Wrong Result?

1. **Log intermediate values** - Temporarily add a CALC that outputs the condition result
2. **Simplify** - Reduce to minimal condition, add back complexity
3. **Check data types** - `"5"` (string) vs `5` (number)
4. **Check null handling** - Is any field null when you expect a value?

### Infinite Loop?

If Field A's predicate affects Field B, and Field B's predicate affects Field A, you can create a loop:

```
A changes → B's predicate runs → B changes → A's predicate runs → A changes → ...
```

The system usually has loop detection, but avoid circular dependencies in design.

---

## Quick Reference

| Action | Purpose | Key Config |
|--------|---------|------------|
| `CALC` | Compute value | `formula` |
| `OPTION_FILTER` | Filter dropdown | `field` |
| `APPLY_ACCESS_MATRIX` | Change visibility/access | `accessMatrix` |
| `VALIDATE` | Show error | `errorMessage` |
| `COPY` | Copy from field | `field` |
| `ASYNC_CALC` | Aggregate from form | `formSchemaIdentifier`, `operation` |
| `CONDITIONAL_FORMAT` | Change appearance | `conditionalFormats` |
| `APPEND` | Add to array | `appendExpression` |
| `GEO_FENCE` | Location validation | `geoFencePredicateConfig` |

---

## Next Steps

Now that you understand predicates:
- **[Master Data](master-data.md)** - How OPTION_FILTER works with external data
- **[Visibility & Access](visibility-access.md)** - Deep dive into access control
- **[Recipes: Cascading Dropdowns](../recipes/cascading-dropdown.md)** - Practical example

