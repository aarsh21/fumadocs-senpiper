# Expressions

## The Expression Engine

Expressions are the programming language inside your forms. Every condition, every formula, every filter—they're all expressions evaluated at runtime.

Understanding expressions is essential because they power:
- Predicate conditions (when should this action run?)
- CALC formulas (what value should this field have?)
- Filter strings (which master data rows match?)
- Validation rules (is this input valid?)

---

## The Runtime Context

When an expression runs, it has access to a **context**—the data available during evaluation.

### The `this` Object

The primary context is `this`, which contains the current form answer:

```javascript
// If the form answer is:
{
  "name": "John Doe",
  "age": 30,
  "address": {
    "city": "Mumbai"
  },
  "items": [
    { "product": "Widget", "qty": 5 },
    { "product": "Gadget", "qty": 3 }
  ]
}

// Then in expressions:
this.name            // "John Doe"
this.age             // 30
this.address.city    // "Mumbai"
this.items[0].product // "Widget"
this.items.length    // 2
```

### Array Index Variables

Inside array contexts, index variables are injected:

```javascript
$i  // Current row index (first-level array)
$j  // Current row index (second-level array)
$k  // Current row index (third-level array)
```

These are **literal replacements**—before the expression runs, `$i` is replaced with the actual number.

---

## Expression Types

### 1. Condition Expressions

Used in `predicate.condition` to determine if an action should run.

**Must return:** `true` or `false`

```json
{
  "condition": "this.country == 'India'"
}
```

**Examples:**
```javascript
// Equality
this.status == 'Active'

// Comparison
this.age >= 18
this.amount > 10000

// Logical AND
this.country == 'India' && this.state == 'Maharashtra'

// Logical OR
this.priority == 'High' || this.priority == 'Critical'

// Negation
this.isDeleted != true
!(this.status == 'Closed')

// Null checks
this.email != null
this.phone != null && this.phone != ''

// Array checks
this.items.length > 0
this.tags.includes('urgent')
```

### 2. Formula Expressions

Used in `CALC` action to compute a value.

**Must return:** The value to store in the field

```json
{
  "action": "CALC",
  "actionConfig": {
    "formula": "this.quantity * this.price"
  }
}
```

**Examples:**
```javascript
// Arithmetic
this.price * this.quantity
this.subtotal + this.tax
(this.basePrice * this.quantity) * (1 - this.discount/100)

// String concatenation
this.firstName + ' ' + this.lastName
this.state + '/' + this.district + '/' + this.block

// Conditional (ternary)
this.age >= 18 ? 'Adult' : 'Minor'
this.score >= 60 ? 'Pass' : 'Fail'

// Complex conditionals
this.amount > 100000 ? 'Large' : (this.amount > 10000 ? 'Medium' : 'Small')

// Using if statements (for complex logic)
if(this.type == 'A') { this.rateA * this.qty } 
else if(this.type == 'B') { this.rateB * this.qty } 
else { this.defaultRate * this.qty }
```

### 3. Filter Expressions

Used in `filterString` to filter master data.

**Must return:** `true` (include row) or `false` (exclude row)

```json
{
  "filterString": "this.state == formAnswer.state"
}
```

In filter expressions, you typically have two contexts:
- `this` - The master data row being evaluated
- `formAnswer` - The form's current answer

---

## JavaScript Operators

Expressions support standard JavaScript operators:

### Arithmetic
| Operator | Description | Example |
|----------|-------------|---------|
| `+` | Addition | `this.a + this.b` |
| `-` | Subtraction | `this.total - this.discount` |
| `*` | Multiplication | `this.qty * this.rate` |
| `/` | Division | `this.total / this.count` |
| `%` | Modulo (remainder) | `this.index % 2` |

### Comparison
| Operator | Description | Example |
|----------|-------------|---------|
| `==` | Equal to | `this.status == 'Active'` |
| `!=` | Not equal to | `this.type != 'Draft'` |
| `>` | Greater than | `this.age > 18` |
| `<` | Less than | `this.score < 60` |
| `>=` | Greater or equal | `this.amount >= 1000` |
| `<=` | Less or equal | `this.qty <= this.maxQty` |

### Logical
| Operator | Description | Example |
|----------|-------------|---------|
| `&&` | AND | `this.a > 0 && this.b > 0` |
| `\|\|` | OR | `this.urgent \|\| this.critical` |
| `!` | NOT | `!this.isDeleted` |

### String
| Operator | Description | Example |
|----------|-------------|---------|
| `+` | Concatenation | `this.first + ' ' + this.last` |

---

## Common Patterns and Techniques

### Null Safety

Always consider that fields might be null or undefined:

```javascript
// Unsafe - fails if email is null
this.email.toLowerCase()

// Safe - check first
this.email != null ? this.email.toLowerCase() : ''

// Or use default
this.email || ''
(this.email || '').toLowerCase()
```

### String Comparison

For case-insensitive comparison:

```javascript
// Case-sensitive (might miss matches)
this.status == 'active'

// Case-insensitive
this.status.toLowerCase() == 'active'
```

### Numeric Defaults

Handle missing numbers:

```javascript
// If qty might be null/undefined
(this.qty || 0) * this.price

// For calculations with defaults
(this.discount || 0) / 100
```

### Array Operations

```javascript
// Check if array has items
this.items && this.items.length > 0

// Check if value exists in array
this.selectedOptions.includes('Option A')

// Array length
this.items.length
```

### Date Comparisons

Dates are often stored as timestamps (milliseconds):

```javascript
// Compare with current date
this.dueDate < Date.now()

// Compare two date fields
this.endDate > this.startDate
```

### Percentage Calculations

```javascript
// Calculate percentage
(this.completed / this.total) * 100

// Apply percentage discount
this.price * (1 - this.discountPercent / 100)

// Tax calculation
this.subtotal * (this.taxRate / 100)
```

---

## Complex Formula Examples

### Example 1: Grading System

```javascript
if(this.score >= 90) { 'A' }
else if(this.score >= 80) { 'B' }
else if(this.score >= 70) { 'C' }
else if(this.score >= 60) { 'D' }
else { 'F' }
```

### Example 2: Price Tier Calculation

```javascript
if(this.quantity >= 100) { this.quantity * this.bulkPrice }
else if(this.quantity >= 50) { this.quantity * this.wholesalePrice }
else { this.quantity * this.retailPrice }
```

### Example 3: Composite Key Generation

```javascript
this.state + '/' + this.district + '/' + this.block + '/' + this.village
```

### Example 4: Age from Birthdate

```javascript
Math.floor((Date.now() - this.birthDate) / (365.25 * 24 * 60 * 60 * 1000))
```

### Example 5: Running Total in Array

For a field inside an array that needs to sum all rows:

```javascript
// This typically requires ASYNC_CALC for proper array aggregation
// Simple formulas operate on single rows
```

### Example 6: Conditional Formatting Score

```javascript
if(this.percentage > 75) { 100 }
else if(this.percentage > 50) { 75 }
else if(this.percentage > 25) { 50 }
else { 25 }
```

---

## Expression Evaluation Timing

Understanding **when** expressions run is crucial:

### Predicate Conditions
- Run when **any field in `formulaKeys` or `dependentKeys` changes**
- Run on form load (initial evaluation)
- Run on form submission (validation)

### CALC Formulas
- Run when triggering field values change
- The result **replaces** the field's current value

### Option Filters
- Run when the filtering source field changes
- Update the available options in dropdowns

### Important: Order Matters

If Field A depends on Field B, and Field B depends on Field C:
```
C changes → B recalculates → A recalculates
```

The system handles this automatically based on `dependentKeys` and `formulaKeys`.

---

## Debugging Expressions

### Common Errors

**1. Reference Error: `this.feildName is not defined`**
- Typo in field key
- Field doesn't exist at that path

**2. Type Error: `Cannot read property 'x' of null`**
- Parent object is null
- Need null checking: `this.parent && this.parent.child`

**3. NaN (Not a Number)**
- Arithmetic with null/undefined values
- Use defaults: `(this.value || 0)`

**4. Unexpected String Concatenation**
- `"5" + "3" = "53"` not `8`
- Convert to number: `Number(this.value) + Number(this.other)`

### Testing Approach

1. **Simplify** - Start with a simple expression, add complexity
2. **Check values** - Use a test field to output intermediate values
3. **Null check** - Add null safety to each part
4. **Console** - If possible, check browser console for errors

---

## Expression Limits

### What You CAN Do
- Basic arithmetic and logic
- String manipulation
- Array access and length
- Ternary conditionals
- if/else statements
- Standard JavaScript methods on strings/arrays

### What You CANNOT Do (typically)
- Define functions
- Use `async`/`await`
- Access external APIs
- Modify `this` directly (except in CALC return)
- Use `console.log` or debugging statements

### Performance Considerations
- Keep expressions simple when possible
- Avoid expensive operations in frequently-triggered fields
- Complex aggregations should use ASYNC_CALC

---

## Quick Reference

### Condition Patterns
```javascript
// Basic equality
this.status == 'Active'

// Multiple conditions (AND)
this.age >= 18 && this.hasConsent == true

// Multiple conditions (OR)  
this.role == 'Admin' || this.role == 'Manager'

// Null check
this.email != null && this.email != ''

// Array has items
this.items && this.items.length > 0

// Value in list
['A', 'B', 'C'].includes(this.grade)
```

### Formula Patterns
```javascript
// Simple calculation
this.qty * this.rate

// With discount
this.subtotal * (1 - this.discount/100)

// String building
this.firstName + ' ' + this.lastName

// Conditional value
this.type == 'Special' ? this.specialRate : this.normalRate

// Safe with defaults
(this.qty || 0) * (this.rate || 0)
```

---

## Next Steps

Now that you understand expressions:
- **[Conditional Logic](conditional-logic.md)** - How expressions power predicates
- **[Field Addressing](field-addressing.md)** - Reference for `this.` paths
- **[Recipes: Calculated Fields](../recipes/calculated-field.md)** - Practical examples

