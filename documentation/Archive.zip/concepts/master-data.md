# Master Data

## What Is Master Data?

Master data is reference data that lives outside your form but powers it. Instead of hardcoding dropdown options like:

```json
{
  "enum": ["Maharashtra", "Karnataka", "Tamil Nadu", "Gujarat", ...]
}
```

You reference a data source:

```json
{
  "masterId": "location-master-uuid",
  "columnKey": "state",
  "masterType": "FORM"
}
```

**Why master data matters:**
- **Single source of truth** - Update once, all forms reflect the change
- **Dynamic filtering** - Cascading dropdowns become trivial
- **Large datasets** - Can't embed 10,000 cities in every form
- **Maintainability** - Non-technical users can update data without touching forms

---

## How Master Data Works

### The Big Picture

```
┌─────────────────────────────────────────────────────────────┐
│                    MASTER DATA FORM                          │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Row 1: { state: "Maharashtra", district: "Mumbai", │    │
│  │          block: "Andheri", ... }                    │    │
│  │  Row 2: { state: "Maharashtra", district: "Mumbai", │    │
│  │          block: "Bandra", ... }                     │    │
│  │  Row 3: { state: "Maharashtra", district: "Pune",   │    │
│  │          block: "Kothrud", ... }                    │    │
│  │  Row 4: { state: "Karnataka", district: "Bangalore",│    │
│  │          block: "Koramangala", ... }                │    │
│  │  ...                                                │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Referenced by
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    YOUR FORM                                 │
│                                                              │
│  State Field:     [Maharashtra ▼]                           │
│                   masterId: "...", columnKey: "state"       │
│                                                              │
│  District Field:  [Mumbai ▼]  ← Filtered by State           │
│                   masterId: "...", columnKey: "district"    │
│                   OPTION_FILTER: field = "state"            │
│                                                              │
│  Block Field:     [Andheri ▼] ← Filtered by District        │
│                   masterId: "...", columnKey: "block"       │
│                   OPTION_FILTER: field = "district"         │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### The Data Flow

1. **Form loads** → Client fetches master data for all referenced masters
2. **Data cached** → Master data stored locally for fast access
3. **Field renders** → Dropdown populated with unique values from the column
4. **User selects** → Value stored, dependent fields triggered
5. **Filter runs** → Dependent dropdowns filter their options based on selection

---

## Master Data Properties

### Essential Properties

```json
{
  "title": "State",
  "type": "string",
  "description": "string_list",
  
  "masterId": "70311147-2fcc-489c-9981-8f374361a229",
  "masterName": "Location Master",
  "masterType": "FORM",
  "columnKey": "s",
  "columnName": "State"
}
```

| Property | Purpose | Example |
|----------|---------|---------|
| `masterId` | UUID of the master data source | `"70311147-2fcc-..."` |
| `masterName` | Human-readable name (display only) | `"Location Master"` |
| `masterType` | Type of master (`"FORM"` or others) | `"FORM"` |
| `columnKey` | Key in master data to use for values | `"s"` |
| `columnName` | Human-readable column name | `"State"` |

**Important distinction:**
- `columnKey` - The field **key** in master data answers (used in code)
- `columnName` - The field **title** in master data schema (for display)

### Group ID for Form Masters

When `masterType` is `"FORM"`, you also need the group:

```json
{
  "masterId": "form-uuid",
  "groupId": "group-uuid",
  "masterType": "FORM"
}
```

The combination `groupId + masterId` identifies the master form uniquely.

---

## Filtering Master Data

### Basic OPTION_FILTER

The most common pattern—filter one field based on another:

```json
{
  "title": "District",
  "masterId": "location-master-uuid",
  "columnKey": "district",
  "predicates": [{
    "action": "OPTION_FILTER",
    "actionConfig": {
      "field": "state"
    }
  }]
}
```

**What happens:**
1. User selects "Maharashtra" in State
2. District's OPTION_FILTER predicate runs
3. System filters master data: only rows where `state == "Maharashtra"`
4. District dropdown shows unique `district` values from filtered rows

### Filter String (Advanced)

For complex filtering logic, use `filterString`:

```json
{
  "title": "Product",
  "masterId": "product-master-uuid",
  "columnKey": "productName",
  "filterString": "this.category == formAnswer.selectedCategory && this.inStock == true"
}
```

In `filterString`:
- `this` refers to each master data row being evaluated
- `formAnswer` refers to the current form's answer

### Filter String Condition (JSON Logic)

For UI-built filters, use the structured format:

```json
{
  "filterStringCondition": {
    "operator": "AND",
    "groups": [
      { "field": "category", "operator": "equals", "value": "Electronics" },
      { "field": "price", "operator": "lessThan", "value": 1000 }
    ]
  }
}
```

---

## Cascading Dropdowns Pattern

This is the most common master data use case. Let's build a complete example:

### Master Data Structure

Your Location Master form has answers like:

```json
[
  { "s": "Maharashtra", "d": "Mumbai", "b": "Andheri", "v": "JVPD" },
  { "s": "Maharashtra", "d": "Mumbai", "b": "Andheri", "v": "4 Bungalows" },
  { "s": "Maharashtra", "d": "Mumbai", "b": "Bandra", "v": "Carter Road" },
  { "s": "Maharashtra", "d": "Pune", "b": "Kothrud", "v": "Paud Road" },
  { "s": "Karnataka", "d": "Bangalore", "b": "Koramangala", "v": "5th Block" },
  ...
]
```

### Form Schema

```json
{
  "properties": {
    "state": {
      "title": "State",
      "type": "string",
      "description": "string_list",
      "masterId": "location-master-uuid",
      "columnKey": "s",
      "dependentKeys": ["district"]
    },
    
    "district": {
      "title": "District",
      "type": "string", 
      "description": "string_list",
      "masterId": "location-master-uuid",
      "columnKey": "d",
      "predicates": [{
        "action": "OPTION_FILTER",
        "actionConfig": { "field": "state" }
      }],
      "dependentKeys": ["block"]
    },
    
    "block": {
      "title": "Block",
      "type": "string",
      "description": "string_list",
      "masterId": "location-master-uuid",
      "columnKey": "b",
      "predicates": [{
        "action": "OPTION_FILTER",
        "actionConfig": { "field": "district" }
      }],
      "dependentKeys": ["village"]
    },
    
    "village": {
      "title": "Village",
      "type": "string",
      "description": "string_list",
      "masterId": "location-master-uuid",
      "columnKey": "v",
      "predicates": [{
        "action": "OPTION_FILTER",
        "actionConfig": { "field": "block" }
      }]
    }
  }
}
```

### How It Flows

1. **State dropdown** shows: Maharashtra, Karnataka, ... (all unique states)
2. User selects **Maharashtra**
3. **District dropdown** filters to: Mumbai, Pune (districts in Maharashtra)
4. User selects **Mumbai**
5. **Block dropdown** filters to: Andheri, Bandra (blocks in Mumbai)
6. User selects **Andheri**
7. **Village dropdown** filters to: JVPD, 4 Bungalows (villages in Andheri)

---

## Searchable Keys

For large master data sets, allow users to search:

```json
{
  "title": "Product",
  "masterId": "product-master-uuid",
  "columnKey": "productCode",
  "searchableKeys": ["productName", "productCode", "category"],
  "enableOnlineSearchableMaster": true
}
```

**`searchableKeys`:** Which columns can be searched when looking for a value.

---

## Master Preview Fields

Show additional info when selecting from master:

```json
{
  "title": "Customer",
  "masterId": "customer-master-uuid",
  "columnKey": "customerId",
  "masterPreviewFields": ["customerName", "email", "phone"]
}
```

When user browses customers, they'll see the ID plus name, email, and phone for context.

---

## Offline vs Online Master

### Offline Master (Default)

```json
{
  "masterId": "...",
  "enableOfflineOptionFilterMaster": true
}
```

- Master data downloaded and cached at form load
- Filtering happens client-side (fast)
- Works without network
- Limited to reasonable data sizes

### Online Master

```json
{
  "masterId": "...",
  "enableOnlineMaster": true,
  "disableOfflineMaster": true
}
```

- Master data fetched on-demand from server
- Better for very large datasets
- Requires network connectivity
- Each filter triggers an API call

### Hybrid Approach

```json
{
  "masterId": "...",
  "enableOnlineSearchableMaster": true
}
```

- Cache common options offline
- Search triggers online lookup for full dataset

---

## Master Filter Configuration

Fine-grained control over how filtering works:

```json
{
  "masterFilterConfig": {
    "location-master-uuid": {
      "filterMode": "EXACT",
      "caseSensitive": false,
      "multiValueSeparator": ","
    }
  }
}
```

| Option | Purpose |
|--------|---------|
| `filterMode` | `"EXACT"`, `"CONTAINS"`, `"STARTS_WITH"` |
| `caseSensitive` | Whether matching is case-sensitive |
| `multiValueSeparator` | For multi-value fields |

---

## Populating Form Fields from Master

When you select a master data row, you might want to populate multiple form fields:

### Using Searchable Keys as Unique Identifier

```json
{
  "title": "Employee",
  "masterId": "employee-master-uuid",
  "columnKey": "employeeId",
  "searchableKeys": ["employeeId"]
}
```

The `searchableKeys` acts as the lookup key—selecting a row by employee ID.

### Auto-populating Related Fields

When a master selection happens, other fields can pull values from the same master row.

This is typically done by:
1. Storing the selected row identifier
2. Using predicates on other fields to copy values from the selected master row

```json
{
  "employeeId": {
    "masterId": "employee-master-uuid",
    "columnKey": "employeeId",
    "dependentKeys": ["employeeName", "department"]
  },
  "employeeName": {
    "predicates": [{
      "action": "CALC",
      "actionConfig": {
        "formula": "/* Get name from selected employee master row */"
      }
    }]
  }
}
```

---

## Common Issues and Solutions

### Issue: Dropdown shows no options

**Causes:**
1. Master data not loaded (check network)
2. `masterId` incorrect
3. `columnKey` doesn't exist in master
4. Filter removed all options

**Debug:** Check that master data returns rows, verify column keys match.

### Issue: Filter not working

**Causes:**
1. `dependentKeys` not set on source field
2. `OPTION_FILTER` action config wrong
3. Column key mismatch between fields

**Debug:** Verify the chain: source field → dependentKeys → target field → OPTION_FILTER → actionConfig.field

### Issue: Duplicate options showing

**Cause:** Master data has duplicate values in the column.

**Solution:** The system should deduplicate. If not, ensure master data is clean.

### Issue: Slow loading with large master

**Solutions:**
1. Use `enableOnlineMaster` for server-side filtering
2. Split master into smaller, focused masters
3. Enable pagination/search instead of loading all

---

## Best Practices

### 1. Design Masters Thoughtfully

Create focused masters rather than one giant master:

```
Good:
- Location Master (state/district/block/village)
- Product Master (product info)
- Customer Master (customer info)

Bad:
- Everything Master (all reference data combined)
```

### 2. Use Consistent Key Naming

In master data, use short but meaningful keys:

```json
{
  "s": "Maharashtra",    // state
  "d": "Mumbai",         // district
  "b": "Andheri",        // block
  "v": "JVPD"           // village
}
```

Keep a mapping document for reference.

### 3. Plan the Cascade

Before building, map out your cascade:

```
State (s)
  └─▶ filters District (d)
        └─▶ filters Block (b)
              └─▶ filters Village (v)
```

### 4. Handle Empty Filters Gracefully

What happens when a user changes State after selecting a Village? The Village might no longer be valid.

Options:
- Clear dependent fields when parent changes
- Show validation error
- Keep value but mark as invalid

### 5. Cache Appropriately

- Small, stable masters: Cache aggressively
- Large masters: Use online search
- Frequently changing masters: Set appropriate cache TTL

---

## Quick Reference

```json
{
  "title": "Field Label",
  "type": "string",
  "description": "string_list",
  
  // Master binding
  "masterId": "uuid",
  "masterName": "Display Name",
  "masterType": "FORM",
  "groupId": "uuid",
  "columnKey": "key",
  "columnName": "Column Display Name",
  
  // Filtering
  "predicates": [{
    "action": "OPTION_FILTER",
    "actionConfig": { "field": "parentFieldKey" }
  }],
  "filterString": "this.column == formAnswer.field",
  
  // Dependencies
  "dependentKeys": ["childField1", "childField2"],
  
  // Search & preview
  "searchableKeys": ["key1", "key2"],
  "masterPreviewFields": ["field1", "field2"],
  
  // Online/Offline
  "enableOfflineOptionFilterMaster": true,
  "enableOnlineMaster": false,
  "enableOnlineSearchableMaster": true,
  "disableOfflineMaster": false
}
```

---

## Next Steps

- **[Conditional Logic](conditional-logic.md)** - More on OPTION_FILTER and predicates
- **[Recipes: Cascading Dropdowns](../recipes/cascading-dropdown.md)** - Complete working example
- **[Visibility & Access](visibility-access.md)** - Access control with master data

